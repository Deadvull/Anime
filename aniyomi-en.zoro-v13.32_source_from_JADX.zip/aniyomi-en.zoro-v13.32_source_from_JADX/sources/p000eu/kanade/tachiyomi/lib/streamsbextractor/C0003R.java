package p000eu.kanade.tachiyomi.lib.streamsbextractor;

/* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.R */
public final class C0003R {
    private C0003R() {
    }
}

package p000eu.kanade.tachiyomi.lib.streamsbextractor;

import android.content.SharedPreferences;
import eu.kanade.tachiyomi.animesource.model.Track;
import eu.kanade.tachiyomi.animesource.model.Video;
import eu.kanade.tachiyomi.network.RequestsKt;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.Json;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Response;

@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 &2\u00020\u0001:\u0001&B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0004J\u0018\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\b\u0010\u0019\u001a\u00020\u0012H\u0002J\b\u0010\u001a\u001a\u00020\u001bH\u0002J0\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001d2\u0006\u0010\u001f\u001a\u00020\u00122\u0006\u0010 \u001a\u00020!2\b\b\u0002\u0010\"\u001a\u00020\u00122\b\b\u0002\u0010#\u001a\u00020\u0012JD\u0010$\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001d2\u0006\u0010\u0016\u001a\u00020\u00122\u0006\u0010 \u001a\u00020!2\b\b\u0002\u0010\"\u001a\u00020\u00122\b\b\u0002\u0010#\u001a\u00020\u00122\b\b\u0002\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010%\u001a\u00020\u0018R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR#\u0010\u000b\u001a\n \r*\u0004\u0018\u00010\f0\f8BX\u0002¢\u0006\f\n\u0004\b\u0010\u0010\n\u001a\u0004\b\u000e\u0010\u000f¨\u0006'"}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/StreamSBExtractor;", "", "client", "Lokhttp3/OkHttpClient;", "(Lokhttp3/OkHttpClient;)V", "json", "Lkotlinx/serialization/json/Json;", "getJson", "()Lkotlinx/serialization/json/Json;", "json$delegate", "Lkotlin/Lazy;", "preferences", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "getPreferences", "()Landroid/content/SharedPreferences;", "preferences$delegate", "bytesToHex", "", "bytes", "", "fixUrl", "url", "common", "", "getEndpoint", "updateEndpoint", "", "videosFromDecryptedUrl", "", "Leu/kanade/tachiyomi/animesource/model/Video;", "realUrl", "headers", "Lokhttp3/Headers;", "prefix", "suffix", "videosFromUrl", "manualData", "Companion", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor */
/* compiled from: StreamSBExtractor.kt */
public final class StreamSBExtractor {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    private static final String ENDPOINT_URL = "https://raw.githubusercontent.com/Claudemirovsky/streamsb-endpoint/master/endpoint.txt";
    private static final String PREF_ENDPOINT_DEFAULT = "/sources16";
    private static final String PREF_ENDPOINT_KEY = "streamsb_api_endpoint";
    private final OkHttpClient client;
    private final Lazy json$delegate = LazyKt.lazy(StreamSBExtractor$special$$inlined$injectLazy$1.INSTANCE);
    private final Lazy preferences$delegate = LazyKt.lazy(new StreamSBExtractor$preferences$2(this));

    public StreamSBExtractor(OkHttpClient okHttpClient) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        this.client = okHttpClient;
    }

    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/StreamSBExtractor$Companion;", "", "()V", "ENDPOINT_URL", "", "PREF_ENDPOINT_DEFAULT", "PREF_ENDPOINT_KEY", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor$Companion */
    /* compiled from: StreamSBExtractor.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    private final Json getJson() {
        return (Json) this.json$delegate.getValue();
    }

    private final SharedPreferences getPreferences() {
        return (SharedPreferences) this.preferences$delegate.getValue();
    }

    private final String getEndpoint() {
        String string = getPreferences().getString(PREF_ENDPOINT_KEY, PREF_ENDPOINT_DEFAULT);
        Intrinsics.checkNotNull(string);
        return string;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x003a, code lost:
        throw r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0036, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0037, code lost:
        kotlin.io.CloseableKt.closeFinally(r0, r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void updateEndpoint() {
        /*
            r4 = this;
            okhttp3.OkHttpClient r0 = r4.client
            r1 = 6
            java.lang.String r2 = "https://raw.githubusercontent.com/Claudemirovsky/streamsb-endpoint/master/endpoint.txt"
            r3 = 0
            okhttp3.Request r1 = eu.kanade.tachiyomi.network.RequestsKt.GET$default(r2, r3, r3, r1, r3)
            okhttp3.Call r0 = r0.newCall(r1)
            okhttp3.Response r0 = r0.execute()
            java.io.Closeable r0 = (java.io.Closeable) r0
            r1 = r0
            okhttp3.Response r1 = (okhttp3.Response) r1     // Catch:{ all -> 0x0034 }
            okhttp3.ResponseBody r1 = r1.body()     // Catch:{ all -> 0x0034 }
            java.lang.String r1 = r1.string()     // Catch:{ all -> 0x0034 }
            kotlin.io.CloseableKt.closeFinally(r0, r3)
            android.content.SharedPreferences r0 = r4.getPreferences()
            android.content.SharedPreferences$Editor r0 = r0.edit()
            java.lang.String r2 = "streamsb_api_endpoint"
            android.content.SharedPreferences$Editor r0 = r0.putString(r2, r1)
            r0.commit()
            return
        L_0x0034:
            r1 = move-exception
            throw r1     // Catch:{ all -> 0x0036 }
        L_0x0036:
            r2 = move-exception
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor.updateEndpoint():void");
    }

    /* access modifiers changed from: protected */
    public final String bytesToHex(byte[] bArr) {
        Intrinsics.checkNotNullParameter(bArr, "bytes");
        char[] charArray = "0123456789ABCDEF".toCharArray();
        Intrinsics.checkNotNullExpressionValue(charArray, "this as java.lang.String).toCharArray()");
        char[] cArr = new char[(bArr.length * 2)];
        int length = bArr.length;
        for (int i = 0; i < length; i++) {
            byte b = bArr[i] & 255;
            int i2 = i * 2;
            cArr[i2] = charArray[b >>> 4];
            cArr[i2 + 1] = charArray[b & 15];
        }
        return new String(cArr);
    }

    private final String fixUrl(String str, boolean z) {
        String str2;
        String host = HttpUrl.Companion.get(str).host();
        String substringAfter$default = StringsKt.substringAfter$default(StringsKt.substringBefore$default(StringsKt.substringBefore$default(StringsKt.substringAfter$default(StringsKt.substringAfter$default(StringsKt.substringAfter$default(str, host, (String) null, 2, (Object) null), "/e/", (String) null, 2, (Object) null), "/embed-", (String) null, 2, (Object) null), "?", (String) null, 2, (Object) null), ".html", (String) null, 2, (Object) null), "/", (String) null, 2, (Object) null);
        StringBuilder sb = new StringBuilder();
        sb.append("https://" + host + getEndpoint());
        if (z) {
            byte[] bytes = substringAfter$default.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
            str2 = "/625a364258615242766475327c7c" + bytesToHex(bytes) + "7c7c4761574550654f7461566d347c7c73747265616d7362";
        } else {
            StringBuilder sb2 = new StringBuilder("/");
            byte[] bytes2 = ("||" + substringAfter$default + "||||streamsb").getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes2, "this as java.lang.String).getBytes(charset)");
            sb2.append(bytesToHex(bytes2));
            sb2.append('/');
            str2 = sb2.toString();
        }
        sb.append(str2);
        return sb.toString();
    }

    public static /* synthetic */ List videosFromUrl$default(StreamSBExtractor streamSBExtractor, String str, Headers headers, String str2, String str3, boolean z, boolean z2, int i, Object obj) {
        return streamSBExtractor.videosFromUrl(str, headers, (i & 4) != 0 ? "" : str2, (i & 8) != 0 ? "" : str3, (i & 16) != 0 ? true : z, (i & 32) != 0 ? false : z2);
    }

    public final List<Video> videosFromUrl(String str, Headers headers, String str2, String str3, boolean z, boolean z2) {
        Headers headers2;
        Object obj;
        String str4;
        String str5;
        List list;
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str6 = str;
        String str7 = str2;
        String str8 = str3;
        boolean z3 = z;
        Intrinsics.checkNotNullParameter(str6, "url");
        Headers headers3 = headers;
        Intrinsics.checkNotNullParameter(headers3, "headers");
        Intrinsics.checkNotNullParameter(str7, "prefix");
        Intrinsics.checkNotNullParameter(str8, "suffix");
        String obj2 = StringsKt.trim(str6).toString();
        if (z2) {
            headers2 = headers3;
        } else {
            headers2 = headers.newBuilder().set("referer", obj2).set("watchsb", "sbstream").set("authority", "embedsb.com").build();
        }
        String str9 = null;
        try {
            Result.Companion companion = Result.Companion;
            StreamSBExtractor streamSBExtractor = this;
            if (z2) {
                str4 = obj2;
            } else {
                str4 = fixUrl(obj2, z3);
            }
            Response execute = this.client.newCall(RequestsKt.GET$default(str4, headers2, (CacheControl) null, 4, (Object) null)).execute();
            Json json = getJson();
            if (execute.code() == 200) {
                Response response = (Closeable) execute;
                try {
                    str5 = response.body().string();
                    CloseableKt.closeFinally(response, (Throwable) null);
                } catch (Throwable th4) {
                    Throwable th5 = th4;
                    CloseableKt.closeFinally(response, th3);
                    throw th5;
                }
            } else {
                execute.close();
                updateEndpoint();
                Response response2 = (Closeable) this.client.newCall(RequestsKt.GET$default(fixUrl(obj2, z3), headers2, (CacheControl) null, 4, (Object) null)).execute();
                try {
                    str5 = response2.body().string();
                    CloseableKt.closeFinally(response2, (Throwable) null);
                } catch (Throwable th6) {
                    Throwable th7 = th6;
                    CloseableKt.closeFinally(response2, th2);
                    throw th7;
                }
            }
            json.getSerializersModule();
            Response response3 = (Response) json.decodeFromString(Response.Companion.serializer(), str5);
            boolean z4 = true;
            String trim = StringsKt.trim(response3.getStream_data().getFile(), new char[]{'\"'});
            List<Subtitle> subs = response3.getStream_data().getSubs();
            if (subs != null) {
                Iterable<Subtitle> iterable = subs;
                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
                for (Subtitle subtitle : iterable) {
                    arrayList.add(new Track(subtitle.getFile(), subtitle.getLabel()));
                }
                list = (List) arrayList;
            } else {
                list = CollectionsKt.emptyList();
            }
            List list2 = list;
            Response response4 = (Closeable) this.client.newCall(RequestsKt.GET$default(trim, headers2, (CacheControl) null, 4, (Object) null)).execute();
            try {
                String string = response4.body().string();
                CloseableKt.closeFinally(response4, (Throwable) null);
                int i = 2;
                List list3 = SequencesKt.toList(SequencesKt.map(Regex.findAll$default(new Regex("#EXT-X-MEDIA:TYPE=AUDIO.*?NAME=\"(.*?)\".*?URI=\"(.*?)\""), string, 0, 2, (Object) null), StreamSBExtractor$videosFromUrl$1$audioList$1.INSTANCE));
                Iterable<String> split$default = StringsKt.split$default(StringsKt.substringAfter$default(string, "#EXT-X-STREAM-INF", (String) null, 2, (Object) null), new String[]{"#EXT-X-STREAM-INF"}, false, 0, 6, (Object) null);
                Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(split$default, 10));
                for (String str10 : split$default) {
                    String str11 = "StreamSB:" + (StringsKt.substringBefore$default(StringsKt.substringAfter$default(StringsKt.substringBefore$default(StringsKt.substringAfter$default(str10, "RESOLUTION=", str9, i, str9), "\n", str9, i, str9), "x", str9, i, str9), ",", str9, i, str9) + 'p');
                    StringBuilder sb = new StringBuilder();
                    if (StringsKt.isBlank(str7) ^ z4) {
                        sb.append(str7 + ' ');
                    }
                    sb.append(str11);
                    if (StringsKt.isBlank(str7) ^ z4) {
                        sb.append(' ' + str8);
                    }
                    String sb2 = sb.toString();
                    Intrinsics.checkNotNullExpressionValue(sb2, "StringBuilder().apply(builderAction).toString()");
                    String substringBefore$default = StringsKt.substringBefore$default(StringsKt.substringAfter$default(str10, "\n", str9, i, str9), "\n", str9, i, str9);
                    Video video = r7;
                    Collection collection = arrayList2;
                    Video video2 = new Video(substringBefore$default, sb2, substringBefore$default, headers2, list2, list3);
                    collection.add(video);
                    arrayList2 = collection;
                    i = 2;
                    str9 = null;
                    z4 = true;
                }
                obj = Result.constructor-impl((List) arrayList2);
                List<Video> list4 = (List) (Result.isFailure-impl(obj) ? null : obj);
                return list4 == null ? CollectionsKt.emptyList() : list4;
            } catch (Throwable th8) {
                Throwable th9 = th8;
                CloseableKt.closeFinally(response4, th);
                throw th9;
            }
        } catch (Throwable th10) {
            Result.Companion companion2 = Result.Companion;
            obj = Result.constructor-impl(ResultKt.createFailure(th10));
        }
    }

    public static /* synthetic */ List videosFromDecryptedUrl$default(StreamSBExtractor streamSBExtractor, String str, Headers headers, String str2, String str3, int i, Object obj) {
        if ((i & 4) != 0) {
            str2 = "";
        }
        if ((i & 8) != 0) {
            str3 = "";
        }
        return streamSBExtractor.videosFromDecryptedUrl(str, headers, str2, str3);
    }

    public final List<Video> videosFromDecryptedUrl(String str, Headers headers, String str2, String str3) {
        Intrinsics.checkNotNullParameter(str, "realUrl");
        Intrinsics.checkNotNullParameter(headers, "headers");
        Intrinsics.checkNotNullParameter(str2, "prefix");
        Intrinsics.checkNotNullParameter(str3, "suffix");
        return videosFromUrl$default(this, str, headers, str2, str3, false, true, 16, (Object) null);
    }
}

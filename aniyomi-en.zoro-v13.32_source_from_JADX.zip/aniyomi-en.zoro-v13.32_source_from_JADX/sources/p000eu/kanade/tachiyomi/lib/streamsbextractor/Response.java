package p000eu.kanade.tachiyomi.lib.streamsbextractor;

import java.util.List;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.SerializationStrategy;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.ArrayListSerializer;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;

@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\b\u0018\u0000 \u001c2\u00020\u0001:\u0003\u001b\u001c\u001dB#\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bB\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\tJ\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u0013\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J!\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aHÇ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u001e"}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/Response;", "", "seen1", "", "stream_data", "Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILeu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;)V", "getStream_data", "()Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;", "component1", "copy", "equals", "", "other", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "$serializer", "Companion", "ResponseObject", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@Serializable
/* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.Response */
/* compiled from: StreamSBExtractorDto.kt */
public final class Response {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    private final ResponseObject stream_data;

    public static /* synthetic */ Response copy$default(Response response, ResponseObject responseObject, int i, Object obj) {
        if ((i & 1) != 0) {
            responseObject = response.stream_data;
        }
        return response.copy(responseObject);
    }

    public final ResponseObject component1() {
        return this.stream_data;
    }

    public final Response copy(ResponseObject responseObject) {
        Intrinsics.checkNotNullParameter(responseObject, "stream_data");
        return new Response(responseObject);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof Response) && Intrinsics.areEqual(this.stream_data, ((Response) obj).stream_data);
    }

    public int hashCode() {
        return this.stream_data.hashCode();
    }

    public String toString() {
        return "Response(stream_data=" + this.stream_data + ')';
    }

    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004HÆ\u0001¨\u0006\u0006"}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/Response$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Leu/kanade/tachiyomi/lib/streamsbextractor/Response;", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.Response$Companion */
    /* compiled from: StreamSBExtractorDto.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final KSerializer<Response> serializer() {
            return (KSerializer) Response$$serializer.INSTANCE;
        }
    }

    @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly", replaceWith = @ReplaceWith(expression = "", imports = {}))
    public /* synthetic */ Response(int i, ResponseObject responseObject, SerializationConstructorMarker serializationConstructorMarker) {
        if (1 != (i & 1)) {
            PluginExceptionsKt.throwMissingFieldException(i, 1, Response$$serializer.INSTANCE.getDescriptor());
        }
        this.stream_data = responseObject;
    }

    public Response(ResponseObject responseObject) {
        Intrinsics.checkNotNullParameter(responseObject, "stream_data");
        this.stream_data = responseObject;
    }

    @Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\b\u0018\u0000 !2\u00020\u0001:\u0002 !B3\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u000e\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\u0002\u0010\u000bB\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\fJ\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\u0011\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007HÆ\u0003J%\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001J!\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fHÇ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0019\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010¨\u0006\""}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;", "", "seen1", "", "file", "", "subs", "", "Leu/kanade/tachiyomi/lib/streamsbextractor/Subtitle;", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/util/List;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Ljava/lang/String;Ljava/util/List;)V", "getFile", "()Ljava/lang/String;", "getSubs", "()Ljava/util/List;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "$serializer", "Companion", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    @Serializable
    /* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.Response$ResponseObject */
    /* compiled from: StreamSBExtractorDto.kt */
    public static final class ResponseObject {
        /* access modifiers changed from: private */
        public static final KSerializer<Object>[] $childSerializers = {null, new ArrayListSerializer(Subtitle$$serializer.INSTANCE)};
        public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
        private final String file;
        private final List<Subtitle> subs;

        public static /* synthetic */ ResponseObject copy$default(ResponseObject responseObject, String str, List<Subtitle> list, int i, Object obj) {
            if ((i & 1) != 0) {
                str = responseObject.file;
            }
            if ((i & 2) != 0) {
                list = responseObject.subs;
            }
            return responseObject.copy(str, list);
        }

        public final String component1() {
            return this.file;
        }

        public final List<Subtitle> component2() {
            return this.subs;
        }

        public final ResponseObject copy(String str, List<Subtitle> list) {
            Intrinsics.checkNotNullParameter(str, "file");
            return new ResponseObject(str, list);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof ResponseObject)) {
                return false;
            }
            ResponseObject responseObject = (ResponseObject) obj;
            return Intrinsics.areEqual(this.file, responseObject.file) && Intrinsics.areEqual(this.subs, responseObject.subs);
        }

        public int hashCode() {
            int hashCode = this.file.hashCode() * 31;
            List<Subtitle> list = this.subs;
            return hashCode + (list == null ? 0 : list.hashCode());
        }

        public String toString() {
            return "ResponseObject(file=" + this.file + ", subs=" + this.subs + ')';
        }

        @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004HÆ\u0001¨\u0006\u0006"}, d2 = {"Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Leu/kanade/tachiyomi/lib/streamsbextractor/Response$ResponseObject;", "lib-streamsb-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
        /* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.Response$ResponseObject$Companion */
        /* compiled from: StreamSBExtractorDto.kt */
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            public final KSerializer<ResponseObject> serializer() {
                return (KSerializer) Response$ResponseObject$$serializer.INSTANCE;
            }
        }

        @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly", replaceWith = @ReplaceWith(expression = "", imports = {}))
        public /* synthetic */ ResponseObject(int i, String str, List list, SerializationConstructorMarker serializationConstructorMarker) {
            if (1 != (i & 1)) {
                PluginExceptionsKt.throwMissingFieldException(i, 1, Response$ResponseObject$$serializer.INSTANCE.getDescriptor());
            }
            this.file = str;
            if ((i & 2) == 0) {
                this.subs = null;
            } else {
                this.subs = list;
            }
        }

        public ResponseObject(String str, List<Subtitle> list) {
            Intrinsics.checkNotNullParameter(str, "file");
            this.file = str;
            this.subs = list;
        }

        @JvmStatic
        public static final /* synthetic */ void write$Self(ResponseObject responseObject, CompositeEncoder compositeEncoder, SerialDescriptor serialDescriptor) {
            SerializationStrategy[] serializationStrategyArr = $childSerializers;
            boolean z = false;
            compositeEncoder.encodeStringElement(serialDescriptor, 0, responseObject.file);
            if (compositeEncoder.shouldEncodeElementDefault(serialDescriptor, 1) || responseObject.subs != null) {
                z = true;
            }
            if (z) {
                compositeEncoder.encodeNullableSerializableElement(serialDescriptor, 1, serializationStrategyArr[1], responseObject.subs);
            }
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        public /* synthetic */ ResponseObject(String str, List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, (i & 2) != 0 ? null : list);
        }

        public final String getFile() {
            return this.file;
        }

        public final List<Subtitle> getSubs() {
            return this.subs;
        }
    }

    public final ResponseObject getStream_data() {
        return this.stream_data;
    }
}

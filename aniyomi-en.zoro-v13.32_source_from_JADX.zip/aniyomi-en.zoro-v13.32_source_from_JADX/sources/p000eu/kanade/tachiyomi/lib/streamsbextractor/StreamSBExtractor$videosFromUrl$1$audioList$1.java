package p000eu.kanade.tachiyomi.lib.streamsbextractor;

import eu.kanade.tachiyomi.animesource.model.Track;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.text.MatchResult;

@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "Leu/kanade/tachiyomi/animesource/model/Track;", "it", "Lkotlin/text/MatchResult;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor$videosFromUrl$1$audioList$1 */
/* compiled from: StreamSBExtractor.kt */
final class StreamSBExtractor$videosFromUrl$1$audioList$1 extends Lambda implements Function1<MatchResult, Track> {
    public static final StreamSBExtractor$videosFromUrl$1$audioList$1 INSTANCE = new StreamSBExtractor$videosFromUrl$1$audioList$1();

    StreamSBExtractor$videosFromUrl$1$audioList$1() {
        super(1);
    }

    public final Track invoke(MatchResult matchResult) {
        Intrinsics.checkNotNullParameter(matchResult, "it");
        return new Track((String) matchResult.getGroupValues().get(2), (String) matchResult.getGroupValues().get(1));
    }
}

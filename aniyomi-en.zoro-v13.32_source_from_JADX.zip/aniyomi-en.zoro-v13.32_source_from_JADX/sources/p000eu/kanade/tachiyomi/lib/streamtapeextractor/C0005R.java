package p000eu.kanade.tachiyomi.lib.streamtapeextractor;

/* renamed from: eu.kanade.tachiyomi.lib.streamtapeextractor.R */
public final class C0005R {
    private C0005R() {
    }
}

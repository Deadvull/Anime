package p000eu.kanade.tachiyomi.lib.streamtapeextractor;

import android.net.Uri;
import eu.kanade.tachiyomi.animesource.model.Video;
import eu.kanade.tachiyomi.network.RequestsKt;
import eu.kanade.tachiyomi.util.JsoupExtensionsKt;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import org.jsoup.nodes.Element;

@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u001a\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Leu/kanade/tachiyomi/lib/streamtapeextractor/StreamTapeExtractor;", "", "client", "Lokhttp3/OkHttpClient;", "(Lokhttp3/OkHttpClient;)V", "videoFromUrl", "Leu/kanade/tachiyomi/animesource/model/Video;", "url", "", "quality", "lib-streamtape-extractor_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.lib.streamtapeextractor.StreamTapeExtractor */
/* compiled from: StreamTapeExtractor.kt */
public final class StreamTapeExtractor {
    private final OkHttpClient client;

    public StreamTapeExtractor(OkHttpClient okHttpClient) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        this.client = okHttpClient;
    }

    public static /* synthetic */ Video videoFromUrl$default(StreamTapeExtractor streamTapeExtractor, String str, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = "StreamTape";
        }
        return streamTapeExtractor.videoFromUrl(str, str2);
    }

    public final Video videoFromUrl(String str, String str2) {
        String data;
        String substringAfter$default;
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(str2, "quality");
        if (!StringsKt.startsWith$default(str, "https://streamtape.com/e/", false, 2, (Object) null)) {
            String str3 = (String) CollectionsKt.getOrNull(StringsKt.split$default(str, new String[]{"/"}, false, 0, 6, (Object) null), 4);
            if (str3 == null) {
                return null;
            }
            str = "https://streamtape.com/e/" + str3;
        }
        Element selectFirst = JsoupExtensionsKt.asJsoup$default(this.client.newCall(RequestsKt.GET$default(str, (Headers) null, (CacheControl) null, 6, (Object) null)).execute(), (String) null, 1, (Object) null).selectFirst("script:containsData(document.getElementById('robotlink'))");
        if (selectFirst == null || (data = selectFirst.data()) == null || (substringAfter$default = StringsKt.substringAfter$default(data, "document.getElementById('robotlink').innerHTML = '", (String) null, 2, (Object) null)) == null) {
            return null;
        }
        String str4 = "https:" + StringsKt.substringBefore$default(substringAfter$default, "'", (String) null, 2, (Object) null) + StringsKt.substringBefore$default(StringsKt.substringAfter$default(substringAfter$default, "+ ('xcd", (String) null, 2, (Object) null), "'", (String) null, 2, (Object) null);
        return new Video(str4, str2, str4, (Uri) null, (Headers) null, 24, (DefaultConstructorMarker) null);
    }
}

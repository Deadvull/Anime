package p000eu.kanade.tachiyomi.lib.core;

/* renamed from: eu.kanade.tachiyomi.lib.core.R */
public final class C0002R {

    /* renamed from: eu.kanade.tachiyomi.lib.core.R$mipmap */
    public static final class mipmap {
        public static int ic_launcher = 2130771968;

        private mipmap() {
        }
    }

    private C0002R() {
    }
}

package p000eu.kanade.tachiyomi.animeextension;

/* renamed from: eu.kanade.tachiyomi.animeextension.R */
public final class C0000R {

    /* renamed from: eu.kanade.tachiyomi.animeextension.R$mipmap */
    public static final class mipmap {
        public static int ic_launcher = 2130771968;

        private mipmap() {
        }
    }

    private C0000R() {
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import androidx.preference.ListPreference;
import androidx.preference.Preference;

/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$$ExternalSyntheticLambda2 */
/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AniWatch$$ExternalSyntheticLambda2 implements Preference.OnPreferenceChangeListener {
    public final /* synthetic */ ListPreference f$0;
    public final /* synthetic */ AniWatch f$1;

    public /* synthetic */ AniWatch$$ExternalSyntheticLambda2(ListPreference listPreference, AniWatch aniWatch) {
        this.f$0 = listPreference;
        this.f$1 = aniWatch;
    }

    public final boolean onPreferenceChange(Preference preference, Object obj) {
        return AniWatch.setupPreferenceScreen$lambda$19$lambda$18(this.f$0, this.f$1, preference, obj);
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import androidx.preference.Preference;
import androidx.preference.SwitchPreferenceCompat;

/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$$ExternalSyntheticLambda4 */
/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AniWatch$$ExternalSyntheticLambda4 implements Preference.OnPreferenceChangeListener {
    public final /* synthetic */ AniWatch f$0;
    public final /* synthetic */ SwitchPreferenceCompat f$1;

    public /* synthetic */ AniWatch$$ExternalSyntheticLambda4(AniWatch aniWatch, SwitchPreferenceCompat switchPreferenceCompat) {
        this.f$0 = aniWatch;
        this.f$1 = switchPreferenceCompat;
    }

    public final boolean onPreferenceChange(Preference preference, Object obj) {
        return AniWatch.setupPreferenceScreen$lambda$23$lambda$22(this.f$0, this.f$1, preference, obj);
    }
}

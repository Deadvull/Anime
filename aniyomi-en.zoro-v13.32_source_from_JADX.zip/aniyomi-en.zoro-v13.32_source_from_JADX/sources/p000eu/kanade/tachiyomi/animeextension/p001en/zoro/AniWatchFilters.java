package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import eu.kanade.tachiyomi.animesource.model.AnimeFilter;
import eu.kanade.tachiyomi.animesource.model.AnimeFilterList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;

@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0015\bÆ\u0002\u0018\u00002\u00020\u0001:\u0013\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0015\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0004H\u0000¢\u0006\u0002\b\nJ\u0015\u0010\u000b\u001a\u00020\f\"\u0006\b\u0000\u0010\r\u0018\u0001*\u00020\u0004H\bR\u0011\u0010\u0003\u001a\u00020\u00048F¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0006¨\u0006!"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters;", "", "()V", "FILTER_LIST", "Leu/kanade/tachiyomi/animesource/model/AnimeFilterList;", "getFILTER_LIST", "()Leu/kanade/tachiyomi/animesource/model/AnimeFilterList;", "getSearchParameters", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$FilterSearchParams;", "filters", "getSearchParameters$aniyomi_en_zoro_v13_32_release", "asQueryPart", "", "R", "AniWatchFiltersData", "CheckBoxFilterList", "CheckBoxVal", "EndDayFilter", "EndMonthFilter", "EndYearFilter", "FilterSearchParams", "GenresFilter", "LanguageFilter", "QueryPartFilter", "RatedFilter", "ScoreFilter", "SeasonFilter", "SortFilter", "StartDayFilter", "StartMonthFilter", "StartYearFilter", "StatusFilter", "TypeFilter", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters */
/* compiled from: AniWatchFilters.kt */
public final class AniWatchFilters {
    public static final AniWatchFilters INSTANCE = new AniWatchFilters();

    private AniWatchFilters() {
    }

    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0016\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u00060\u0005¢\u0006\u0002\u0010\u0007J\u0006\u0010\u000b\u001a\u00020\u0002R%\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u00060\u0005¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\b\u0010\t¨\u0006\f"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "Leu/kanade/tachiyomi/animesource/model/AnimeFilter$Select;", "", "displayName", "vals", "", "Lkotlin/Pair;", "(Ljava/lang/String;[Lkotlin/Pair;)V", "getVals", "()[Lkotlin/Pair;", "[Lkotlin/Pair;", "toQueryPart", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$QueryPartFilter */
    /* compiled from: AniWatchFilters.kt */
    public static class QueryPartFilter extends AnimeFilter.Select<String> {
        private final Pair<String, String>[] vals;

        public final Pair<String, String>[] getVals() {
            return this.vals;
        }

        public final String toQueryPart() {
            return (String) this.vals[((Number) getState()).intValue()].getSecond();
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public QueryPartFilter(java.lang.String r9, kotlin.Pair<java.lang.String, java.lang.String>[] r10) {
            /*
                r8 = this;
                java.lang.String r0 = "displayName"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
                java.lang.String r0 = "vals"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
                java.util.ArrayList r0 = new java.util.ArrayList
                int r1 = r10.length
                r0.<init>(r1)
                java.util.Collection r0 = (java.util.Collection) r0
                int r1 = r10.length
                r2 = 0
                r3 = 0
            L_0x0015:
                if (r3 >= r1) goto L_0x0025
                r4 = r10[r3]
                java.lang.Object r4 = r4.getFirst()
                java.lang.String r4 = (java.lang.String) r4
                r0.add(r4)
                int r3 = r3 + 1
                goto L_0x0015
            L_0x0025:
                java.util.List r0 = (java.util.List) r0
                java.util.Collection r0 = (java.util.Collection) r0
                java.lang.String[] r1 = new java.lang.String[r2]
                java.lang.Object[] r4 = r0.toArray(r1)
                r5 = 0
                r6 = 4
                r7 = 0
                r2 = r8
                r3 = r9
                r2.<init>(r3, r4, r5, r6, r7)
                r8.vals = r10
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.QueryPartFilter.<init>(java.lang.String, kotlin.Pair[]):void");
        }
    }

    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\b\u0016\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001b\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00020\u0006¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$CheckBoxFilterList;", "Leu/kanade/tachiyomi/animesource/model/AnimeFilter$Group;", "Leu/kanade/tachiyomi/animesource/model/AnimeFilter$CheckBox;", "name", "", "values", "", "(Ljava/lang/String;Ljava/util/List;)V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$CheckBoxFilterList */
    /* compiled from: AniWatchFilters.kt */
    public static class CheckBoxFilterList extends AnimeFilter.Group<AnimeFilter.CheckBox> {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public CheckBoxFilterList(String str, List<? extends AnimeFilter.CheckBox> list) {
            super(str, list);
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(list, "values");
        }
    }

    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006¨\u0006\u0007"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$CheckBoxVal;", "Leu/kanade/tachiyomi/animesource/model/AnimeFilter$CheckBox;", "name", "", "state", "", "(Ljava/lang/String;Z)V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$CheckBoxVal */
    /* compiled from: AniWatchFilters.kt */
    private static final class CheckBoxVal extends AnimeFilter.CheckBox {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public CheckBoxVal(String str, boolean z) {
            super(str, z);
            Intrinsics.checkNotNullParameter(str, "name");
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        public /* synthetic */ CheckBoxVal(String str, boolean z, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, (i & 2) != 0 ? false : z);
        }
    }

    private final /* synthetic */ <R> String asQueryPart(AnimeFilterList animeFilterList) {
        Collection arrayList = new ArrayList();
        for (Object next : (Iterable) animeFilterList) {
            Intrinsics.reifiedOperationMarker(3, "R");
            if (next instanceof Object) {
                arrayList.add(next);
            }
        }
        Intrinsics.needClassReification();
        return CollectionsKt.joinToString$default((List) arrayList, "", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, AniWatchFilters$asQueryPart$1.INSTANCE, 30, (Object) null);
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$TypeFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$TypeFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class TypeFilter extends QueryPartFilter {
        public TypeFilter() {
            super("Type", AniWatchFiltersData.INSTANCE.getTYPES());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$StatusFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$StatusFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class StatusFilter extends QueryPartFilter {
        public StatusFilter() {
            super("Status", AniWatchFiltersData.INSTANCE.getSTATUS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$RatedFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$RatedFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class RatedFilter extends QueryPartFilter {
        public RatedFilter() {
            super("Rated", AniWatchFiltersData.INSTANCE.getRATED());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$ScoreFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$ScoreFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class ScoreFilter extends QueryPartFilter {
        public ScoreFilter() {
            super("Score", AniWatchFiltersData.INSTANCE.getSCORES());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$SeasonFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$SeasonFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class SeasonFilter extends QueryPartFilter {
        public SeasonFilter() {
            super("Season", AniWatchFiltersData.INSTANCE.getSEASONS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$LanguageFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$LanguageFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class LanguageFilter extends QueryPartFilter {
        public LanguageFilter() {
            super("Language", AniWatchFiltersData.INSTANCE.getLANGUAGES());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$SortFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$SortFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class SortFilter extends QueryPartFilter {
        public SortFilter() {
            super("Sort by", AniWatchFiltersData.INSTANCE.getSORTS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$StartYearFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$StartYearFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class StartYearFilter extends QueryPartFilter {
        public StartYearFilter() {
            super("Start year", AniWatchFiltersData.INSTANCE.getYEARS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$StartMonthFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$StartMonthFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class StartMonthFilter extends QueryPartFilter {
        public StartMonthFilter() {
            super("Start month", AniWatchFiltersData.INSTANCE.getMONTHS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$StartDayFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$StartDayFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class StartDayFilter extends QueryPartFilter {
        public StartDayFilter() {
            super("Start day", AniWatchFiltersData.INSTANCE.getDAYS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$EndYearFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$EndYearFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class EndYearFilter extends QueryPartFilter {
        public EndYearFilter() {
            super("End year", AniWatchFiltersData.INSTANCE.getYEARS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$EndMonthFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$EndMonthFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class EndMonthFilter extends QueryPartFilter {
        public EndMonthFilter() {
            super("End month", AniWatchFiltersData.INSTANCE.getMONTHS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$EndDayFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$QueryPartFilter;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$EndDayFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class EndDayFilter extends QueryPartFilter {
        public EndDayFilter() {
            super("End day", AniWatchFiltersData.INSTANCE.getDAYS());
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$GenresFilter;", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$CheckBoxFilterList;", "()V", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$GenresFilter */
    /* compiled from: AniWatchFilters.kt */
    public static final class GenresFilter extends CheckBoxFilterList {
        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public GenresFilter() {
            /*
                r7 = this;
                eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$AniWatchFiltersData r0 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.AniWatchFiltersData.INSTANCE
                kotlin.Pair[] r0 = r0.getGENRES()
                java.util.ArrayList r1 = new java.util.ArrayList
                int r2 = r0.length
                r1.<init>(r2)
                java.util.Collection r1 = (java.util.Collection) r1
                int r2 = r0.length
                r3 = 0
                r4 = 0
            L_0x0011:
                if (r4 >= r2) goto L_0x0026
                r5 = r0[r4]
                eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$CheckBoxVal r6 = new eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$CheckBoxVal
                java.lang.Object r5 = r5.getFirst()
                java.lang.String r5 = (java.lang.String) r5
                r6.<init>(r5, r3)
                r1.add(r6)
                int r4 = r4 + 1
                goto L_0x0011
            L_0x0026:
                java.util.List r1 = (java.util.List) r1
                java.lang.String r0 = "Genres"
                r7.<init>(r0, r1)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.GenresFilter.<init>():void");
        }
    }

    public final AnimeFilterList getFILTER_LIST() {
        return new AnimeFilterList(new AnimeFilter[]{new TypeFilter(), new StatusFilter(), new RatedFilter(), new ScoreFilter(), new SeasonFilter(), new LanguageFilter(), new SortFilter(), new AnimeFilter.Separator((String) null, 1, (DefaultConstructorMarker) null), new StartYearFilter(), new StartMonthFilter(), new StartDayFilter(), new EndYearFilter(), new EndMonthFilter(), new EndDayFilter(), new AnimeFilter.Separator((String) null, 1, (DefaultConstructorMarker) null), new GenresFilter()});
    }

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b-\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\b\u0018\u00002\u00020\u0001B\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0003¢\u0006\u0002\u0010\u0011J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0003HÆ\u0003J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\t\u0010'\u001a\u00020\u0003HÆ\u0003J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\t\u0010)\u001a\u00020\u0003HÆ\u0003J\t\u0010*\u001a\u00020\u0003HÆ\u0003J\t\u0010+\u001a\u00020\u0003HÆ\u0003J\t\u0010,\u001a\u00020\u0003HÆ\u0003J\t\u0010-\u001a\u00020\u0003HÆ\u0003J\t\u0010.\u001a\u00020\u0003HÆ\u0003J\u0001\u0010/\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u0003HÆ\u0001J\u0013\u00100\u001a\u0002012\b\u00102\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00103\u001a\u000204HÖ\u0001J\t\u00105\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u000f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u000e\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\r\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0013R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0013R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0013R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0013R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0013R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0013R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0013¨\u00066"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$FilterSearchParams;", "", "type", "", "status", "rated", "score", "season", "language", "sort", "start_year", "start_month", "start_day", "end_year", "end_month", "end_day", "genres", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getEnd_day", "()Ljava/lang/String;", "getEnd_month", "getEnd_year", "getGenres", "getLanguage", "getRated", "getScore", "getSeason", "getSort", "getStart_day", "getStart_month", "getStart_year", "getStatus", "getType", "component1", "component10", "component11", "component12", "component13", "component14", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "", "toString", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams */
    /* compiled from: AniWatchFilters.kt */
    public static final class FilterSearchParams {
        private final String end_day;
        private final String end_month;
        private final String end_year;
        private final String genres;
        private final String language;
        private final String rated;
        private final String score;
        private final String season;
        private final String sort;
        private final String start_day;
        private final String start_month;
        private final String start_year;
        private final String status;
        private final String type;

        public FilterSearchParams() {
            this((String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, 16383, (DefaultConstructorMarker) null);
        }

        public static /* synthetic */ FilterSearchParams copy$default(FilterSearchParams filterSearchParams, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, int i, Object obj) {
            FilterSearchParams filterSearchParams2 = filterSearchParams;
            int i2 = i;
            return filterSearchParams.copy((i2 & 1) != 0 ? filterSearchParams2.type : str, (i2 & 2) != 0 ? filterSearchParams2.status : str2, (i2 & 4) != 0 ? filterSearchParams2.rated : str3, (i2 & 8) != 0 ? filterSearchParams2.score : str4, (i2 & 16) != 0 ? filterSearchParams2.season : str5, (i2 & 32) != 0 ? filterSearchParams2.language : str6, (i2 & 64) != 0 ? filterSearchParams2.sort : str7, (i2 & 128) != 0 ? filterSearchParams2.start_year : str8, (i2 & 256) != 0 ? filterSearchParams2.start_month : str9, (i2 & 512) != 0 ? filterSearchParams2.start_day : str10, (i2 & 1024) != 0 ? filterSearchParams2.end_year : str11, (i2 & 2048) != 0 ? filterSearchParams2.end_month : str12, (i2 & 4096) != 0 ? filterSearchParams2.end_day : str13, (i2 & 8192) != 0 ? filterSearchParams2.genres : str14);
        }

        public final String component1() {
            return this.type;
        }

        public final String component10() {
            return this.start_day;
        }

        public final String component11() {
            return this.end_year;
        }

        public final String component12() {
            return this.end_month;
        }

        public final String component13() {
            return this.end_day;
        }

        public final String component14() {
            return this.genres;
        }

        public final String component2() {
            return this.status;
        }

        public final String component3() {
            return this.rated;
        }

        public final String component4() {
            return this.score;
        }

        public final String component5() {
            return this.season;
        }

        public final String component6() {
            return this.language;
        }

        public final String component7() {
            return this.sort;
        }

        public final String component8() {
            return this.start_year;
        }

        public final String component9() {
            return this.start_month;
        }

        public final FilterSearchParams copy(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14) {
            String str15 = str;
            Intrinsics.checkNotNullParameter(str15, "type");
            String str16 = str2;
            Intrinsics.checkNotNullParameter(str16, "status");
            String str17 = str3;
            Intrinsics.checkNotNullParameter(str17, "rated");
            String str18 = str4;
            Intrinsics.checkNotNullParameter(str18, "score");
            String str19 = str5;
            Intrinsics.checkNotNullParameter(str19, "season");
            String str20 = str6;
            Intrinsics.checkNotNullParameter(str20, "language");
            String str21 = str7;
            Intrinsics.checkNotNullParameter(str21, "sort");
            String str22 = str8;
            Intrinsics.checkNotNullParameter(str22, "start_year");
            String str23 = str9;
            Intrinsics.checkNotNullParameter(str23, "start_month");
            String str24 = str10;
            Intrinsics.checkNotNullParameter(str24, "start_day");
            String str25 = str11;
            Intrinsics.checkNotNullParameter(str25, "end_year");
            String str26 = str12;
            Intrinsics.checkNotNullParameter(str26, "end_month");
            String str27 = str13;
            Intrinsics.checkNotNullParameter(str27, "end_day");
            String str28 = str14;
            Intrinsics.checkNotNullParameter(str28, "genres");
            return new FilterSearchParams(str15, str16, str17, str18, str19, str20, str21, str22, str23, str24, str25, str26, str27, str28);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof FilterSearchParams)) {
                return false;
            }
            FilterSearchParams filterSearchParams = (FilterSearchParams) obj;
            return Intrinsics.areEqual(this.type, filterSearchParams.type) && Intrinsics.areEqual(this.status, filterSearchParams.status) && Intrinsics.areEqual(this.rated, filterSearchParams.rated) && Intrinsics.areEqual(this.score, filterSearchParams.score) && Intrinsics.areEqual(this.season, filterSearchParams.season) && Intrinsics.areEqual(this.language, filterSearchParams.language) && Intrinsics.areEqual(this.sort, filterSearchParams.sort) && Intrinsics.areEqual(this.start_year, filterSearchParams.start_year) && Intrinsics.areEqual(this.start_month, filterSearchParams.start_month) && Intrinsics.areEqual(this.start_day, filterSearchParams.start_day) && Intrinsics.areEqual(this.end_year, filterSearchParams.end_year) && Intrinsics.areEqual(this.end_month, filterSearchParams.end_month) && Intrinsics.areEqual(this.end_day, filterSearchParams.end_day) && Intrinsics.areEqual(this.genres, filterSearchParams.genres);
        }

        public int hashCode() {
            return (((((((((((((((((((((((((this.type.hashCode() * 31) + this.status.hashCode()) * 31) + this.rated.hashCode()) * 31) + this.score.hashCode()) * 31) + this.season.hashCode()) * 31) + this.language.hashCode()) * 31) + this.sort.hashCode()) * 31) + this.start_year.hashCode()) * 31) + this.start_month.hashCode()) * 31) + this.start_day.hashCode()) * 31) + this.end_year.hashCode()) * 31) + this.end_month.hashCode()) * 31) + this.end_day.hashCode()) * 31) + this.genres.hashCode();
        }

        public String toString() {
            return "FilterSearchParams(type=" + this.type + ", status=" + this.status + ", rated=" + this.rated + ", score=" + this.score + ", season=" + this.season + ", language=" + this.language + ", sort=" + this.sort + ", start_year=" + this.start_year + ", start_month=" + this.start_month + ", start_day=" + this.start_day + ", end_year=" + this.end_year + ", end_month=" + this.end_month + ", end_day=" + this.end_day + ", genres=" + this.genres + ')';
        }

        public FilterSearchParams(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14) {
            Intrinsics.checkNotNullParameter(str, "type");
            Intrinsics.checkNotNullParameter(str2, "status");
            Intrinsics.checkNotNullParameter(str3, "rated");
            Intrinsics.checkNotNullParameter(str4, "score");
            Intrinsics.checkNotNullParameter(str5, "season");
            Intrinsics.checkNotNullParameter(str6, "language");
            Intrinsics.checkNotNullParameter(str7, "sort");
            Intrinsics.checkNotNullParameter(str8, "start_year");
            Intrinsics.checkNotNullParameter(str9, "start_month");
            Intrinsics.checkNotNullParameter(str10, "start_day");
            Intrinsics.checkNotNullParameter(str11, "end_year");
            Intrinsics.checkNotNullParameter(str12, "end_month");
            Intrinsics.checkNotNullParameter(str13, "end_day");
            Intrinsics.checkNotNullParameter(str14, "genres");
            this.type = str;
            this.status = str2;
            this.rated = str3;
            this.score = str4;
            this.season = str5;
            this.language = str6;
            this.sort = str7;
            this.start_year = str8;
            this.start_month = str9;
            this.start_day = str10;
            this.end_year = str11;
            this.end_month = str12;
            this.end_day = str13;
            this.genres = str14;
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public /* synthetic */ FilterSearchParams(java.lang.String r16, java.lang.String r17, java.lang.String r18, java.lang.String r19, java.lang.String r20, java.lang.String r21, java.lang.String r22, java.lang.String r23, java.lang.String r24, java.lang.String r25, java.lang.String r26, java.lang.String r27, java.lang.String r28, java.lang.String r29, int r30, kotlin.jvm.internal.DefaultConstructorMarker r31) {
            /*
                r15 = this;
                r0 = r30
                r1 = r0 & 1
                java.lang.String r2 = ""
                if (r1 == 0) goto L_0x000a
                r1 = r2
                goto L_0x000c
            L_0x000a:
                r1 = r16
            L_0x000c:
                r3 = r0 & 2
                if (r3 == 0) goto L_0x0012
                r3 = r2
                goto L_0x0014
            L_0x0012:
                r3 = r17
            L_0x0014:
                r4 = r0 & 4
                if (r4 == 0) goto L_0x001a
                r4 = r2
                goto L_0x001c
            L_0x001a:
                r4 = r18
            L_0x001c:
                r5 = r0 & 8
                if (r5 == 0) goto L_0x0022
                r5 = r2
                goto L_0x0024
            L_0x0022:
                r5 = r19
            L_0x0024:
                r6 = r0 & 16
                if (r6 == 0) goto L_0x002a
                r6 = r2
                goto L_0x002c
            L_0x002a:
                r6 = r20
            L_0x002c:
                r7 = r0 & 32
                if (r7 == 0) goto L_0x0032
                r7 = r2
                goto L_0x0034
            L_0x0032:
                r7 = r21
            L_0x0034:
                r8 = r0 & 64
                if (r8 == 0) goto L_0x003a
                r8 = r2
                goto L_0x003c
            L_0x003a:
                r8 = r22
            L_0x003c:
                r9 = r0 & 128(0x80, float:1.794E-43)
                if (r9 == 0) goto L_0x0042
                r9 = r2
                goto L_0x0044
            L_0x0042:
                r9 = r23
            L_0x0044:
                r10 = r0 & 256(0x100, float:3.59E-43)
                if (r10 == 0) goto L_0x004a
                r10 = r2
                goto L_0x004c
            L_0x004a:
                r10 = r24
            L_0x004c:
                r11 = r0 & 512(0x200, float:7.175E-43)
                if (r11 == 0) goto L_0x0052
                r11 = r2
                goto L_0x0054
            L_0x0052:
                r11 = r25
            L_0x0054:
                r12 = r0 & 1024(0x400, float:1.435E-42)
                if (r12 == 0) goto L_0x005a
                r12 = r2
                goto L_0x005c
            L_0x005a:
                r12 = r26
            L_0x005c:
                r13 = r0 & 2048(0x800, float:2.87E-42)
                if (r13 == 0) goto L_0x0062
                r13 = r2
                goto L_0x0064
            L_0x0062:
                r13 = r27
            L_0x0064:
                r14 = r0 & 4096(0x1000, float:5.74E-42)
                if (r14 == 0) goto L_0x006a
                r14 = r2
                goto L_0x006c
            L_0x006a:
                r14 = r28
            L_0x006c:
                r0 = r0 & 8192(0x2000, float:1.14794E-41)
                if (r0 == 0) goto L_0x0071
                goto L_0x0073
            L_0x0071:
                r2 = r29
            L_0x0073:
                r16 = r15
                r17 = r1
                r18 = r3
                r19 = r4
                r20 = r5
                r21 = r6
                r22 = r7
                r23 = r8
                r24 = r9
                r25 = r10
                r26 = r11
                r27 = r12
                r28 = r13
                r29 = r14
                r30 = r2
                r16.<init>(r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.FilterSearchParams.<init>(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
        }

        public final String getType() {
            return this.type;
        }

        public final String getStatus() {
            return this.status;
        }

        public final String getRated() {
            return this.rated;
        }

        public final String getScore() {
            return this.score;
        }

        public final String getSeason() {
            return this.season;
        }

        public final String getLanguage() {
            return this.language;
        }

        public final String getSort() {
            return this.sort;
        }

        public final String getStart_year() {
            return this.start_year;
        }

        public final String getStart_month() {
            return this.start_month;
        }

        public final String getStart_day() {
            return this.start_day;
        }

        public final String getEnd_year() {
            return this.end_year;
        }

        public final String getEnd_month() {
            return this.end_month;
        }

        public final String getEnd_day() {
            return this.end_day;
        }

        public final String getGenres() {
            return this.genres;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v47, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v28, resolved type: kotlin.Pair} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.FilterSearchParams getSearchParameters$aniyomi_en_zoro_v13_32_release(eu.kanade.tachiyomi.animesource.model.AnimeFilterList r28) {
        /*
            r27 = this;
            r0 = r28
            java.lang.String r1 = "filters"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)
            boolean r1 = r28.isEmpty()
            if (r1 == 0) goto L_0x0027
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams r0 = new eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams
            r2 = r0
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 16383(0x3fff, float:2.2957E-41)
            r18 = 0
            r2.<init>(r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18)
            return r0
        L_0x0027:
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Iterator r2 = r0.iterator()
        L_0x0034:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0046
            java.lang.Object r3 = r2.next()
            boolean r4 = r3 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.GenresFilter
            if (r4 == 0) goto L_0x0034
            r1.add(r3)
            goto L_0x0034
        L_0x0046:
            java.util.List r1 = (java.util.List) r1
            java.lang.Object r1 = kotlin.collections.CollectionsKt.first(r1)
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$GenresFilter r1 = (p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.GenresFilter) r1
            java.lang.Object r1 = r1.getState()
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r1 = r1.iterator()
        L_0x005f:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x00a7
            java.lang.Object r3 = r1.next()
            eu.kanade.tachiyomi.animesource.model.AnimeFilter$CheckBox r3 = (eu.kanade.tachiyomi.animesource.model.AnimeFilter.CheckBox) r3
            java.lang.Object r4 = r3.getState()
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            r5 = 0
            if (r4 == 0) goto L_0x00a1
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$AniWatchFiltersData r4 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.AniWatchFiltersData.INSTANCE
            kotlin.Pair[] r4 = r4.getGENRES()
            int r6 = r4.length
            r7 = 0
        L_0x0080:
            if (r7 >= r6) goto L_0x0097
            r8 = r4[r7]
            java.lang.Object r9 = r8.getFirst()
            java.lang.String r10 = r3.getName()
            boolean r9 = kotlin.jvm.internal.Intrinsics.areEqual(r9, r10)
            if (r9 == 0) goto L_0x0094
            r5 = r8
            goto L_0x0097
        L_0x0094:
            int r7 = r7 + 1
            goto L_0x0080
        L_0x0097:
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)
            java.lang.Object r3 = r5.getSecond()
            r5 = r3
            java.lang.String r5 = (java.lang.String) r5
        L_0x00a1:
            if (r5 == 0) goto L_0x005f
            r2.add(r5)
            goto L_0x005f
        L_0x00a7:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            java.lang.String r1 = ","
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            r10 = 62
            r11 = 0
            java.lang.String r26 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Iterator r2 = r0.iterator()
        L_0x00c8:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x00da
            java.lang.Object r3 = r2.next()
            boolean r4 = r3 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.TypeFilter
            if (r4 == 0) goto L_0x00c8
            r1.add(r3)
            goto L_0x00c8
        L_0x00da:
            java.util.List r1 = (java.util.List) r1
            r2 = r1
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.lang.String r1 = ""
            r3 = r1
            java.lang.CharSequence r3 = (java.lang.CharSequence) r3
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$1 r8 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$1.INSTANCE
            kotlin.jvm.functions.Function1 r8 = (kotlin.jvm.functions.Function1) r8
            r9 = 30
            r10 = 0
            java.lang.String r13 = kotlin.collections.CollectionsKt.joinToString$default(r2, r3, r4, r5, r6, r7, r8, r9, r10)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x00fe:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0110
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.StatusFilter
            if (r5 == 0) goto L_0x00fe
            r2.add(r4)
            goto L_0x00fe
        L_0x0110:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$2 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$2.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r14 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x0133:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0145
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.RatedFilter
            if (r5 == 0) goto L_0x0133
            r2.add(r4)
            goto L_0x0133
        L_0x0145:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$3 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$3.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r15 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x0168:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x017a
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.ScoreFilter
            if (r5 == 0) goto L_0x0168
            r2.add(r4)
            goto L_0x0168
        L_0x017a:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$4 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$4.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r16 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x019d:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x01af
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.SeasonFilter
            if (r5 == 0) goto L_0x019d
            r2.add(r4)
            goto L_0x019d
        L_0x01af:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$5 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$5.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r17 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x01d2:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x01e4
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.LanguageFilter
            if (r5 == 0) goto L_0x01d2
            r2.add(r4)
            goto L_0x01d2
        L_0x01e4:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$6 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$6.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r18 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x0207:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0219
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.SortFilter
            if (r5 == 0) goto L_0x0207
            r2.add(r4)
            goto L_0x0207
        L_0x0219:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$7 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$7.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r19 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x023c:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x024e
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.StartYearFilter
            if (r5 == 0) goto L_0x023c
            r2.add(r4)
            goto L_0x023c
        L_0x024e:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$8 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$8.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r20 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x0271:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0283
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.StartMonthFilter
            if (r5 == 0) goto L_0x0271
            r2.add(r4)
            goto L_0x0271
        L_0x0283:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$9 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$9.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r21 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x02a6:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x02b8
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.StartDayFilter
            if (r5 == 0) goto L_0x02a6
            r2.add(r4)
            goto L_0x02a6
        L_0x02b8:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$10 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$10.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r22 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x02db:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x02ed
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.EndYearFilter
            if (r5 == 0) goto L_0x02db
            r2.add(r4)
            goto L_0x02db
        L_0x02ed:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$11 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$11.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r23 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r3 = r0.iterator()
        L_0x0310:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0322
            java.lang.Object r4 = r3.next()
            boolean r5 = r4 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.EndMonthFilter
            if (r5 == 0) goto L_0x0310
            r2.add(r4)
            goto L_0x0310
        L_0x0322:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$12 r2 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$12.INSTANCE
            r9 = r2
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r24 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Collection r2 = (java.util.Collection) r2
            java.util.Iterator r0 = r0.iterator()
        L_0x0345:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x0357
            java.lang.Object r3 = r0.next()
            boolean r4 = r3 instanceof p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.EndDayFilter
            if (r4 == 0) goto L_0x0345
            r2.add(r3)
            goto L_0x0345
        L_0x0357:
            java.util.List r2 = (java.util.List) r2
            r3 = r2
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            r4 = r1
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$13 r0 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters$getSearchParameters$$inlined$asQueryPart$13.INSTANCE
            r9 = r0
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = 30
            r11 = 0
            java.lang.String r25 = kotlin.collections.CollectionsKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams r0 = new eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams
            r12 = r0
            r12.<init>(r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters.getSearchParameters$aniyomi_en_zoro_v13_32_release(eu.kanade.tachiyomi.animesource.model.AnimeFilterList):eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$FilterSearchParams");
    }

    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0018\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001d\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R%\u0010\b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR%\u0010\r\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u000e\u0010\u000bR%\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u0010\u0010\u000bR%\u0010\u0011\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u0012\u0010\u000bR%\u0010\u0013\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u0014\u0010\u000bR%\u0010\u0015\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u0016\u0010\u000bR%\u0010\u0017\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u0018\u0010\u000bR%\u0010\u0019\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u001a\u0010\u000bR%\u0010\u001b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u001c\u0010\u000bR%\u0010\u001d\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\u001e\u0010\u000bR%\u0010\u001f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00040\t¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b \u0010\u000b¨\u0006!"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$AniWatchFiltersData;", "", "()V", "ALL", "Lkotlin/Pair;", "", "getALL", "()Lkotlin/Pair;", "DAYS", "", "getDAYS", "()[Lkotlin/Pair;", "[Lkotlin/Pair;", "GENRES", "getGENRES", "LANGUAGES", "getLANGUAGES", "MONTHS", "getMONTHS", "RATED", "getRATED", "SCORES", "getSCORES", "SEASONS", "getSEASONS", "SORTS", "getSORTS", "STATUS", "getSTATUS", "TYPES", "getTYPES", "YEARS", "getYEARS", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchFilters$AniWatchFiltersData */
    /* compiled from: AniWatchFilters.kt */
    private static final class AniWatchFiltersData {
        private static final Pair<String, String> ALL;
        private static final Pair<String, String>[] DAYS;
        private static final Pair<String, String>[] GENRES = {new Pair<>("Action", "1"), new Pair<>("Adventure", "2"), new Pair<>("Cars", "3"), new Pair<>("Comedy", "4"), new Pair<>("Dementia", "5"), new Pair<>("Demons", "6"), new Pair<>("Drama", "8"), new Pair<>("Ecchi", "9"), new Pair<>("Fantasy", "10"), new Pair<>("Game", "11"), new Pair<>("Harem", "35"), new Pair<>("Historical", "13"), new Pair<>("Horror", "14"), new Pair<>("Isekai", "44"), new Pair<>("Josei", "43"), new Pair<>("Kids", "15"), new Pair<>("Magic", "16"), new Pair<>("Martial Arts", "17"), new Pair<>("Mecha", "18"), new Pair<>("Military", "38"), new Pair<>("Music", "19"), new Pair<>("Mystery", "7"), new Pair<>("Parody", "20"), new Pair<>("Police", "39"), new Pair<>("Psychological", "40"), new Pair<>("Romance", "22"), new Pair<>("Samurai", "21"), new Pair<>("School", "23"), new Pair<>("Sci-Fi", "24"), new Pair<>("Seinen", "42"), new Pair<>("Shoujo", "25"), new Pair<>("Shoujo Ai", "26"), new Pair<>("Shounen", "27"), new Pair<>("Shounen Ai", "28"), new Pair<>("Slice of Life", "36"), new Pair<>("Space", "29"), new Pair<>("Sports", "30"), new Pair<>("Super Power", "31"), new Pair<>("Supernatural", "37"), new Pair<>("Thriller", "41"), new Pair<>("Vampire", "32"), new Pair<>("Yaoi", "33"), new Pair<>("Yuri", "34")};
        public static final AniWatchFiltersData INSTANCE = new AniWatchFiltersData();
        private static final Pair<String, String>[] LANGUAGES;
        private static final Pair<String, String>[] MONTHS;
        private static final Pair<String, String>[] RATED;
        private static final Pair<String, String>[] SCORES;
        private static final Pair<String, String>[] SEASONS;
        private static final Pair<String, String>[] SORTS = {new Pair<>("Default", "default"), new Pair<>("Recently Added", "recently_added"), new Pair<>("Recently Updated", "recently_updated"), new Pair<>("Score", "score"), new Pair<>("Name A-Z", "name_az"), new Pair<>("Released Date", "released_date"), new Pair<>("Most Watched", "most_watched")};
        private static final Pair<String, String>[] STATUS;
        private static final Pair<String, String>[] TYPES;
        private static final Pair<String, String>[] YEARS;

        private AniWatchFiltersData() {
        }

        static {
            Pair<String, String> pair = new Pair<>("All", "");
            ALL = pair;
            TYPES = new Pair[]{pair, new Pair<>("Movie", "1"), new Pair<>("TV", "2"), new Pair<>("OVA", "3"), new Pair<>("ONA", "4"), new Pair<>("Special", "5"), new Pair<>("Music", "6")};
            STATUS = new Pair[]{pair, new Pair<>("Finished Airing", "1"), new Pair<>("Currently Airing", "2"), new Pair<>("Not yet aired", "3")};
            RATED = new Pair[]{pair, new Pair<>("G", "1"), new Pair<>("PG", "2"), new Pair<>("PG-13", "3"), new Pair<>("R", "4"), new Pair<>("R+", "5"), new Pair<>("Rx", "6")};
            SCORES = new Pair[]{pair, new Pair<>("(1) Appalling", "1"), new Pair<>("(2) Horrible", "2"), new Pair<>("(3) Very Bad", "3"), new Pair<>("(4) Bad", "4"), new Pair<>("(5) Average", "5"), new Pair<>("(6) Fine", "6"), new Pair<>("(7) Good", "7"), new Pair<>("(8) Very Good", "8"), new Pair<>("(9) Great", "9"), new Pair<>("(10) Masterpiece", "10")};
            SEASONS = new Pair[]{pair, new Pair<>("Spring", "1"), new Pair<>("Summer", "2"), new Pair<>("Fall", "3"), new Pair<>("Winter", "4")};
            LANGUAGES = new Pair[]{pair, new Pair<>("SUB", "1"), new Pair<>("DUB", "2"), new Pair<>("SUB & DUB", "3")};
            Pair[] pairArr = {pair};
            Iterable intRange = new IntRange(1917, 2023);
            Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange, 10));
            IntIterator it = intRange.iterator();
            while (it.hasNext()) {
                int nextInt = it.nextInt();
                arrayList.add(new Pair(String.valueOf(nextInt), String.valueOf(nextInt)));
            }
            YEARS = (Pair[]) ArraysKt.plus(pairArr, CollectionsKt.reversed((List) arrayList).toArray(new Pair[0]));
            Pair[] pairArr2 = {ALL};
            Iterable intRange2 = new IntRange(1, 12);
            Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange2, 10));
            IntIterator it2 = intRange2.iterator();
            while (it2.hasNext()) {
                int nextInt2 = it2.nextInt();
                arrayList2.add(new Pair(String.valueOf(nextInt2), String.valueOf(nextInt2)));
            }
            MONTHS = (Pair[]) ArraysKt.plus(pairArr2, ((List) arrayList2).toArray(new Pair[0]));
            Pair[] pairArr3 = {ALL};
            Iterable intRange3 = new IntRange(1, 31);
            Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRange3, 10));
            IntIterator it3 = intRange3.iterator();
            while (it3.hasNext()) {
                int nextInt3 = it3.nextInt();
                arrayList3.add(new Pair(String.valueOf(nextInt3), String.valueOf(nextInt3)));
            }
            DAYS = (Pair[]) ArraysKt.plus(pairArr3, ((List) arrayList3).toArray(new Pair[0]));
        }

        public final Pair<String, String> getALL() {
            return ALL;
        }

        public final Pair<String, String>[] getTYPES() {
            return TYPES;
        }

        public final Pair<String, String>[] getSTATUS() {
            return STATUS;
        }

        public final Pair<String, String>[] getRATED() {
            return RATED;
        }

        public final Pair<String, String>[] getSCORES() {
            return SCORES;
        }

        public final Pair<String, String>[] getSEASONS() {
            return SEASONS;
        }

        public final Pair<String, String>[] getLANGUAGES() {
            return LANGUAGES;
        }

        public final Pair<String, String>[] getSORTS() {
            return SORTS;
        }

        public final Pair<String, String>[] getYEARS() {
            return YEARS;
        }

        public final Pair<String, String>[] getMONTHS() {
            return MONTHS;
        }

        public final Pair<String, String>[] getDAYS() {
            return DAYS;
        }

        public final Pair<String, String>[] getGENRES() {
            return GENRES;
        }
    }
}

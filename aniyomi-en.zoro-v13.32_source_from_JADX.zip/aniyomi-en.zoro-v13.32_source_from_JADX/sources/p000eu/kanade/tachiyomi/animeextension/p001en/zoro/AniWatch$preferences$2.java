package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import android.app.Application;
import android.content.SharedPreferences;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import uy.kohesive.injekt.InjektKt;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\n \u0002*\u0004\u0018\u00010\u00010\u0001H\n¢\u0006\u0002\b\u0003"}, d2 = {"<anonymous>", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$preferences$2 */
/* compiled from: AniWatch.kt */
final class AniWatch$preferences$2 extends Lambda implements Function0<SharedPreferences> {
    final /* synthetic */ AniWatch this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AniWatch$preferences$2(AniWatch aniWatch) {
        super(0);
        this.this$0 = aniWatch;
    }

    public final SharedPreferences invoke() {
        return ((Application) InjektKt.getInjekt().getInstance(new AniWatch$preferences$2$invoke$$inlined$get$1().getType())).getSharedPreferences("source_" + this.this$0.getId(), 0);
    }
}

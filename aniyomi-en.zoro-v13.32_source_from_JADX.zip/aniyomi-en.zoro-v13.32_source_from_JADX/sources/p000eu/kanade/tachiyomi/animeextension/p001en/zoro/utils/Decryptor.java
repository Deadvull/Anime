package p000eu.kanade.tachiyomi.animeextension.p001en.zoro.utils;

import android.util.Base64;
import java.security.DigestException;
import java.security.MessageDigest;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004JH\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\b2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\t2\b\b\u0002\u0010\f\u001a\u00020\u00042\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u000e2\b\b\u0002\u0010\u0010\u001a\u00020\u000eH\u0002¨\u0006\u0011"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/utils/Decryptor;", "", "()V", "decrypt", "", "encodedData", "remoteKey", "generateKeyAndIv", "", "", "password", "salt", "hashAlgorithm", "keyLength", "", "ivLength", "iterations", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.utils.Decryptor */
/* compiled from: Decryptor.kt */
public final class Decryptor {
    public static final Decryptor INSTANCE = new Decryptor();

    private Decryptor() {
    }

    public final String decrypt(String str, String str2) {
        Intrinsics.checkNotNullParameter(str, "encodedData");
        Intrinsics.checkNotNullParameter(str2, "remoteKey");
        byte[] decode = Base64.decode(str, 0);
        Intrinsics.checkNotNullExpressionValue(decode, "saltedData");
        byte[] copyOfRange = ArraysKt.copyOfRange(decode, 8, 16);
        byte[] copyOfRange2 = ArraysKt.copyOfRange(decode, 16, decode.length);
        byte[] bytes = str2.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
        List generateKeyAndIv$default = generateKeyAndIv$default(this, bytes, copyOfRange, (String) null, 0, 0, 0, 60, (Object) null);
        if (generateKeyAndIv$default == null) {
            return null;
        }
        SecretKeySpec secretKeySpec = new SecretKeySpec((byte[]) generateKeyAndIv$default.get(0), "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec((byte[]) generateKeyAndIv$default.get(1));
        Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
        instance.init(2, secretKeySpec, ivParameterSpec);
        byte[] doFinal = instance.doFinal(copyOfRange2);
        Intrinsics.checkNotNullExpressionValue(doFinal, "cipher.doFinal(ciphertext)");
        return new String(doFinal, Charsets.UTF_8);
    }

    static /* synthetic */ List generateKeyAndIv$default(Decryptor decryptor, byte[] bArr, byte[] bArr2, String str, int i, int i2, int i3, int i4, Object obj) {
        if ((i4 & 4) != 0) {
            str = "MD5";
        }
        return decryptor.generateKeyAndIv(bArr, bArr2, str, (i4 & 8) != 0 ? 32 : i, (i4 & 16) != 0 ? 16 : i2, (i4 & 32) != 0 ? 1 : i3);
    }

    private final List<byte[]> generateKeyAndIv(byte[] bArr, byte[] bArr2, String str, int i, int i2, int i3) {
        MessageDigest instance = MessageDigest.getInstance(str);
        int digestLength = instance.getDigestLength();
        int i4 = i2 + i;
        byte[] bArr3 = new byte[((((i4 + digestLength) - 1) / digestLength) * digestLength)];
        try {
            instance.reset();
            for (int i5 = 0; i5 < i4; i5 += digestLength) {
                if (i5 > 0) {
                    instance.update(bArr3, i5 - digestLength, digestLength);
                }
                instance.update(bArr);
                instance.update(bArr2, 0, 8);
                instance.digest(bArr3, i5, digestLength);
                for (int i6 = 1; i6 < i3; i6++) {
                    instance.update(bArr3, i5, digestLength);
                    instance.digest(bArr3, i5, digestLength);
                }
            }
            return CollectionsKt.listOf((Object[]) new byte[][]{ArraysKt.copyOfRange(bArr3, 0, i), ArraysKt.copyOfRange(bArr3, i, i4)});
        } catch (DigestException unused) {
            return null;
        }
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro.utils;

import app.cash.quickjs.QuickJs;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004J\u0018\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0002¨\u0006\b"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/utils/FindPassword;", "", "()V", "getPassword", "", "js", "getPasswordFromJS", "getKeyArgs", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.utils.FindPassword */
/* compiled from: FindPassword.kt */
public final class FindPassword {
    public static final FindPassword INSTANCE = new FindPassword();

    private FindPassword() {
    }

    public final String getPassword(String str) {
        Intrinsics.checkNotNullParameter(str, "js");
        String obj = StringsKt.trim(StringsKt.substringAfterLast$default(StringsKt.substringBeforeLast$default(StringsKt.substringBefore$default(StringsKt.substringAfter$default(str, "CryptoJS[", (String) null, 2, (Object) null), "JSON", (String) null, 2, (Object) null), ")", (String) null, 2, (Object) null), ",", (String) null, 2, (Object) null)).toString();
        String substringBefore = StringsKt.substringBefore(StringsKt.substringAfter(str, "const " + obj + '=', ""), ";", "");
        if (!(!StringsKt.isBlank(substringBefore))) {
            String substringBeforeLast$default = StringsKt.substringBeforeLast$default(StringsKt.substringBefore$default(str, "jwplayer(", (String) null, 2, (Object) null), "var", (String) null, 2, (Object) null);
            String substringAfterLast$default = StringsKt.substringAfterLast$default(StringsKt.substringBeforeLast$default(substringBeforeLast$default, "'", (String) null, 2, (Object) null), "'", (String) null, 2, (Object) null);
            if (substringAfterLast$default.length() >= 8) {
                return substringAfterLast$default;
            }
            String substringBefore$default = StringsKt.substringBefore$default(StringsKt.substringAfterLast$default(substringBeforeLast$default, "(0x", (String) null, 2, (Object) null), ")", (String) null, 2, (Object) null);
            return getPasswordFromJS(str, "(0x" + substringBefore$default + ')');
        } else if (StringsKt.startsWith$default(substringBefore, "'", false, 2, (Object) null)) {
            return StringsKt.trim(substringBefore, new char[]{'\''});
        } else {
            return getPasswordFromJS(str, "(" + StringsKt.substringAfter$default(substringBefore, "(", (String) null, 2, (Object) null));
        }
    }

    private final String getPasswordFromJS(String str, String str2) {
        String str3 = "(function" + StringsKt.substringAfter$default(StringsKt.substringBefore$default(str, ",(!function", (String) null, 2, (Object) null), "(function", (String) null, 2, (Object) null) + ')';
        String substringBefore$default = StringsKt.substringBefore$default(StringsKt.substringAfter$default(str3, "=", (String) null, 2, (Object) null), ",", (String) null, 2, (Object) null);
        String str4 = "function " + substringBefore$default;
        String substringAfter$default = StringsKt.substringAfter$default(str, str4, (String) null, 2, (Object) null);
        String str5 = substringBefore$default + StringsKt.substringBefore$default(substringAfter$default, "{", (String) null, 2, (Object) null) + ";}";
        String str6 = str4 + StringsKt.substringBefore$default(substringAfter$default, str5, (String) null, 2, (Object) null) + str5;
        String substring = str.substring(0, 20);
        Intrinsics.checkNotNullExpressionValue(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        if (!StringsKt.contains$default(substring, "=[", false, 2, (Object) null)) {
            String substringBefore$default2 = StringsKt.substringBefore$default(StringsKt.substringAfter$default(str6, "=", (String) null, 2, (Object) null), ";", (String) null, 2, (Object) null);
            String str7 = "function " + substringBefore$default2;
            String str8 = "return " + substringBefore$default2 + ";}";
            str3 = str3 + "\n\n" + (str7 + StringsKt.substringBefore$default(StringsKt.substringAfter$default(str, str7, (String) null, 2, (Object) null), str8, (String) null, 2, (Object) null) + str8);
        }
        String str9 = (str3 + "\n\n" + str6) + "\n\n" + substringBefore$default + str2;
        QuickJs create = QuickJs.create();
        Intrinsics.checkNotNullExpressionValue(create, "create()");
        String valueOf = String.valueOf(create.evaluate(str9));
        create.close();
        return valueOf;
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import android.content.SharedPreferences;
import android.net.Uri;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceScreen;
import androidx.preference.SwitchPreferenceCompat;
import eu.kanade.tachiyomi.animesource.ConfigurableAnimeSource;
import eu.kanade.tachiyomi.animesource.model.AnimeFilterList;
import eu.kanade.tachiyomi.animesource.model.AnimesPage;
import eu.kanade.tachiyomi.animesource.model.SAnime;
import eu.kanade.tachiyomi.animesource.model.SEpisode;
import eu.kanade.tachiyomi.animesource.model.Track;
import eu.kanade.tachiyomi.animesource.model.Video;
import eu.kanade.tachiyomi.animesource.online.ParsedAnimeHttpSource;
import eu.kanade.tachiyomi.network.OkHttpExtensionsKt;
import eu.kanade.tachiyomi.network.RequestsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.MagicApiIntrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KType;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.serialization.SerializersKt;
import kotlinx.serialization.json.Json;
import kotlinx.serialization.json.JsonElement;
import kotlinx.serialization.json.JsonElementKt;
import kotlinx.serialization.json.JsonObject;
import kotlinx.serialization.modules.SerializersModule;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchFilters;
import p000eu.kanade.tachiyomi.animeextension.p001en.zoro.extractors.AniWatchExtractor;
import p000eu.kanade.tachiyomi.animeextension.p001en.zoro.utils.JSONUtil;
import rx.Observable;

@Metadata(d1 = {"\u0000Ì\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u001c\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\u0018\u0000 s2\u00020\u00012\u00020\u0002:\u0001sB\u0005¢\u0006\u0002\u0010\u0003J\u0010\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020'H\u0014J\u0010\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020+H\u0014J\u0016\u0010,\u001a\b\u0012\u0004\u0012\u00020.0-2\u0006\u0010/\u001a\u000200H\u0014J\u0010\u00101\u001a\u0002022\u0006\u00103\u001a\u00020%H\u0014J\b\u00104\u001a\u00020\u0005H\u0014J&\u00105\u001a\b\u0012\u0004\u0012\u000207062\u0006\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u00052\u0006\u0010;\u001a\u00020<H\u0016J\b\u0010=\u001a\u00020<H\u0016J(\u0010>\u001a\n\u0012\u0004\u0012\u00020?\u0018\u00010-2\u0006\u0010@\u001a\u00020\u00052\u0006\u0010A\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u0005H\u0002J\u0010\u0010B\u001a\u00020%2\u0006\u0010*\u001a\u00020+H\u0014J\b\u0010C\u001a\u00020\u0005H\u0014J\u0010\u0010D\u001a\u0002022\u0006\u00108\u001a\u000209H\u0014J\b\u0010E\u001a\u00020\u0005H\u0014J\u0012\u0010F\u001a\u0002092\b\u0010G\u001a\u0004\u0018\u00010\u0005H\u0002J\u0010\u0010H\u001a\u00020%2\u0006\u0010*\u001a\u00020+H\u0014J\b\u0010I\u001a\u00020\u0005H\u0014J\u0010\u0010J\u001a\u0002022\u0006\u00108\u001a\u000209H\u0014J\b\u0010K\u001a\u00020\u0005H\u0014J\u0018\u0010L\u001a\u0002072\u0006\u0010/\u001a\u0002002\u0006\u0010M\u001a\u00020\u0005H\u0002J\u0010\u0010N\u001a\u00020%2\u0006\u0010*\u001a\u00020+H\u0014J\b\u0010O\u001a\u00020\u0005H\u0014J \u0010P\u001a\u0002022\u0006\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u00052\u0006\u0010;\u001a\u00020QH\u0002J \u0010P\u001a\u0002022\u0006\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u00052\u0006\u0010;\u001a\u00020<H\u0014J\b\u0010R\u001a\u00020\u0005H\u0014J\u0010\u0010S\u001a\u00020T2\u0006\u0010U\u001a\u00020VH\u0016J\u001c\u0010W\u001a\b\u0012\u0004\u0012\u00020X0-2\f\u0010Y\u001a\b\u0012\u0004\u0012\u00020X0-H\u0002J\u0010\u0010Z\u001a\u00020)2\u0006\u0010*\u001a\u00020+H\u0014J\u0016\u0010[\u001a\b\u0012\u0004\u0012\u00020?0-2\u0006\u0010/\u001a\u000200H\u0014J\u0010\u0010\\\u001a\u0002022\u0006\u0010]\u001a\u00020.H\u0014J\b\u0010^\u001a\u00020)H\u0014J\u0010\u0010_\u001a\u00020)2\u0006\u0010&\u001a\u00020'H\u0014J\u001c\u0010`\u001a\u00020a*\u00020a2\u0006\u0010:\u001a\u00020\u00052\u0006\u0010b\u001a\u00020\u0005H\u0002J*\u0010c\u001a\u0004\u0018\u00010\u0005*\u00020+2\u0006\u0010d\u001a\u00020\u00052\b\b\u0002\u0010e\u001a\u00020!2\b\b\u0002\u0010f\u001a\u00020!H\u0002JP\u0010g\u001a\b\u0012\u0004\u0012\u0002Hh0-\"\u0004\b\u0000\u0010i\"\u0004\b\u0001\u0010h*\b\u0012\u0004\u0012\u0002Hi0j2\"\u0010k\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002Hi\u0012\n\u0012\b\u0012\u0004\u0012\u0002Hh0m\u0012\u0006\u0012\u0004\u0018\u00010n0lH\u0002ø\u0001\u0000¢\u0006\u0002\u0010oJ\u0018\u0010p\u001a\b\u0012\u0004\u0012\u00020?0-*\b\u0012\u0004\u0012\u00020?0-H\u0014J \u0010q\u001a\b\u0012\u0004\u0012\u00020?0-*\b\u0012\u0004\u0012\u00020?0-2\u0006\u0010r\u001a\u00020\u0005H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058VX\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0014\u0010\n\u001a\u00020\u000bX\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\u00020\u000fXD¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001b\u0010\u0012\u001a\u00020\u00138BX\u0002¢\u0006\f\n\u0004\b\u0016\u0010\t\u001a\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0017\u001a\u00020\u0005XD¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0007R\u0014\u0010\u0019\u001a\u00020\u0005XD¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0007R\u001b\u0010\u001b\u001a\u00020\u001c8BX\u0002¢\u0006\f\n\u0004\b\u001f\u0010\t\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010 \u001a\u00020!XD¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#\u0002\u0004\n\u0002\b\u0019¨\u0006t"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatch;", "Leu/kanade/tachiyomi/animesource/ConfigurableAnimeSource;", "Leu/kanade/tachiyomi/animesource/online/ParsedAnimeHttpSource;", "()V", "baseUrl", "", "getBaseUrl", "()Ljava/lang/String;", "baseUrl$delegate", "Lkotlin/Lazy;", "client", "Lokhttp3/OkHttpClient;", "getClient", "()Lokhttp3/OkHttpClient;", "id", "", "getId", "()J", "json", "Lkotlinx/serialization/json/Json;", "getJson", "()Lkotlinx/serialization/json/Json;", "json$delegate", "lang", "getLang", "name", "getName", "preferences", "Landroid/content/SharedPreferences;", "getPreferences", "()Landroid/content/SharedPreferences;", "preferences$delegate", "supportsLatest", "", "getSupportsLatest", "()Z", "animeDetailsParse", "Leu/kanade/tachiyomi/animesource/model/SAnime;", "document", "Lorg/jsoup/nodes/Document;", "episodeFromElement", "", "element", "Lorg/jsoup/nodes/Element;", "episodeListParse", "", "Leu/kanade/tachiyomi/animesource/model/SEpisode;", "response", "Lokhttp3/Response;", "episodeListRequest", "Lokhttp3/Request;", "anime", "episodeListSelector", "fetchSearchAnime", "Lrx/Observable;", "Leu/kanade/tachiyomi/animesource/model/AnimesPage;", "page", "", "query", "filters", "Leu/kanade/tachiyomi/animesource/model/AnimeFilterList;", "getFilterList", "getVideosFromServer", "Leu/kanade/tachiyomi/animesource/model/Video;", "source", "subDub", "latestUpdatesFromElement", "latestUpdatesNextPageSelector", "latestUpdatesRequest", "latestUpdatesSelector", "parseStatus", "statusString", "popularAnimeFromElement", "popularAnimeNextPageSelector", "popularAnimeRequest", "popularAnimeSelector", "searchAnimeBySlugParse", "slug", "searchAnimeFromElement", "searchAnimeNextPageSelector", "searchAnimeRequest", "Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchFilters$FilterSearchParams;", "searchAnimeSelector", "setupPreferenceScreen", "", "screen", "Landroidx/preference/PreferenceScreen;", "subLangOrder", "Leu/kanade/tachiyomi/animesource/model/Track;", "tracks", "videoFromElement", "videoListParse", "videoListRequest", "episode", "videoListSelector", "videoUrlParse", "addIfNotBlank", "Lokhttp3/HttpUrl$Builder;", "value", "getInfo", "tag", "isList", "full", "parallelMap", "B", "A", "", "f", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "(Ljava/lang/Iterable;Lkotlin/jvm/functions/Function2;)Ljava/util/List;", "sort", "sortIfContains", "item", "Companion", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch */
/* compiled from: AniWatch.kt */
public final class AniWatch extends ParsedAnimeHttpSource implements ConfigurableAnimeSource {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    private static final boolean MARK_FILLERS_DEFAULT = true;
    private static final String MARK_FILLERS_KEY = "mark_fillers";
    private static final String MARK_FILLERS_TITLE = "Mark filler episodes";
    public static final String PREFIX_SEARCH = "slug:";
    private static final String PREF_DOMAIN_DEFAULT = "https://kaido.to";
    private static final String[] PREF_DOMAIN_ENTRIES = {"kaido.to", "aniwatch.to"};
    private static final String[] PREF_DOMAIN_ENTRY_VALUES = {PREF_DOMAIN_DEFAULT, "https://aniwatch.to"};
    private static final String PREF_DOMAIN_KEY = "preferred_domain";
    private static final String PREF_DOMAIN_TITLE = "Preferred domain (requires app restart)";
    private static final String[] PREF_QUALITY_ENTRIES = {"360p", "720p", "1080p"};
    private static final String PREF_QUALITY_KEY = "preferred_quality";
    private static final String PREF_QUALITY_TITLE = "Preferred video quality";
    private static final String[] PREF_SUB_ENTRIES = {"English", "Spanish", "Portuguese", "French", "German", "Italian", "Japanese", "Russian", "Arabic"};
    private static final String PREF_SUB_KEY = "preferred_subLang";
    private static final String PREF_SUB_TITLE = "Preferred sub language";
    private static final String[] PREF_TYPE_ENTRIES = {"sub", "dub"};
    private static final String PREF_TYPE_KEY = "preferred_type";
    private static final String PREF_TYPE_TITLE = "Preferred episode type/mode";
    private final Lazy baseUrl$delegate = LazyKt.lazy(new AniWatch$baseUrl$2(this));
    private final OkHttpClient client = getNetwork().getCloudflareClient();

    /* renamed from: id */
    private final long f0id = 6706411382606718900L;
    private final Lazy json$delegate = LazyKt.lazy(AniWatch$special$$inlined$injectLazy$1.INSTANCE);
    private final String lang = "en";
    private final String name = "AniWatch.to";
    private final Lazy preferences$delegate = LazyKt.lazy(new AniWatch$preferences$2(this));
    private final boolean supportsLatest = MARK_FILLERS_DEFAULT;

    /* access modifiers changed from: protected */
    public String episodeListSelector() {
        return "ul#episode_page li a";
    }

    /* access modifiers changed from: protected */
    public String popularAnimeNextPageSelector() {
        return "li.page-item a[title=Next]";
    }

    /* access modifiers changed from: protected */
    public String popularAnimeSelector() {
        return "div.flw-item";
    }

    public String getName() {
        return this.name;
    }

    public String getBaseUrl() {
        return (String) this.baseUrl$delegate.getValue();
    }

    public long getId() {
        return this.f0id;
    }

    public String getLang() {
        return this.lang;
    }

    public boolean getSupportsLatest() {
        return this.supportsLatest;
    }

    public OkHttpClient getClient() {
        return this.client;
    }

    private final Json getJson() {
        return (Json) this.json$delegate.getValue();
    }

    /* access modifiers changed from: private */
    public final SharedPreferences getPreferences() {
        Object value = this.preferences$delegate.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "<get-preferences>(...)");
        return (SharedPreferences) value;
    }

    /* access modifiers changed from: protected */
    public Request popularAnimeRequest(int i) {
        return RequestsKt.GET$default(getBaseUrl() + "/most-popular?page=" + i, (Headers) null, (CacheControl) null, 6, (Object) null);
    }

    /* access modifiers changed from: protected */
    public SAnime popularAnimeFromElement(Element element) {
        Intrinsics.checkNotNullParameter(element, "element");
        SAnime create = SAnime.Companion.create();
        Element selectFirst = element.selectFirst("div.film-poster > img");
        Intrinsics.checkNotNull(selectFirst);
        create.setThumbnail_url(selectFirst.attr("data-src"));
        Element selectFirst2 = element.selectFirst("div.film-detail a");
        Intrinsics.checkNotNull(selectFirst2);
        String attr = selectFirst2.attr("href");
        Intrinsics.checkNotNullExpressionValue(attr, "filmDetail.attr(\"href\")");
        setUrlWithoutDomain(create, attr);
        String attr2 = selectFirst2.attr("data-jname");
        Intrinsics.checkNotNullExpressionValue(attr2, "filmDetail.attr(\"data-jname\")");
        create.setTitle(attr2);
        return create;
    }

    /* access modifiers changed from: protected */
    public Request episodeListRequest(SAnime sAnime) {
        Intrinsics.checkNotNullParameter(sAnime, "anime");
        String substringAfterLast$default = StringsKt.substringAfterLast$default(sAnime.getUrl(), "-", (String) null, 2, (Object) null);
        Headers.Companion companion = Headers.Companion;
        Headers of = companion.of(new String[]{"Referer", getBaseUrl() + sAnime.getUrl()});
        String str = Intrinsics.areEqual(getBaseUrl(), PREF_DOMAIN_DEFAULT) ? "" : "/v2";
        return RequestsKt.GET$default(getBaseUrl() + "/ajax" + str + "/episode/list/" + substringAfterLast$default, of, (CacheControl) null, 4, (Object) null);
    }

    /* access modifiers changed from: protected */
    public List<SEpisode> episodeListParse(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        Iterable select = Jsoup.parse(JSONUtil.INSTANCE.unescape(StringsKt.substringBefore$default(StringsKt.substringAfter$default(response.body().string(), "\"html\":\"", (String) null, 2, (Object) null), "<script>", (String) null, 2, (Object) null))).select("a.ep-item");
        Intrinsics.checkNotNullExpressionValue(select, "document.select(\"a.ep-item\")");
        Iterable<Element> iterable = select;
        Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
        for (Element element : iterable) {
            SEpisode create = SEpisode.Companion.create();
            String attr = element.attr("data-number");
            Intrinsics.checkNotNullExpressionValue(attr, "it.attr(\"data-number\")");
            create.setEpisode_number(Float.parseFloat(attr));
            create.setName("Episode " + element.attr("data-number") + ": " + element.attr("title"));
            String attr2 = element.attr("href");
            Intrinsics.checkNotNullExpressionValue(attr2, "it.attr(\"href\")");
            create.setUrl(attr2);
            if (element.hasClass("ssl-item-filler") && getPreferences().getBoolean(MARK_FILLERS_KEY, MARK_FILLERS_DEFAULT)) {
                create.setScanlator("Filler Episode");
            }
            arrayList.add(create);
        }
        return CollectionsKt.reversed((List) arrayList);
    }

    /* access modifiers changed from: protected */
    public Void episodeFromElement(Element element) {
        Intrinsics.checkNotNullParameter(element, "element");
        throw new Exception("not used");
    }

    /* access modifiers changed from: protected */
    public Request videoListRequest(SEpisode sEpisode) {
        Intrinsics.checkNotNullParameter(sEpisode, "episode");
        String substringAfterLast$default = StringsKt.substringAfterLast$default(sEpisode.getUrl(), "?ep=", (String) null, 2, (Object) null);
        Headers.Companion companion = Headers.Companion;
        Headers of = companion.of(new String[]{"Referer", getBaseUrl() + sEpisode.getUrl()});
        String str = Intrinsics.areEqual(getBaseUrl(), PREF_DOMAIN_DEFAULT) ? "" : "/v2";
        return RequestsKt.GET$default(getBaseUrl() + "/ajax" + str + "/episode/servers?episodeId=" + substringAfterLast$default, of, (CacheControl) null, 4, (Object) null);
    }

    /* access modifiers changed from: protected */
    public List<Video> videoListParse(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        String string = response.body().string();
        Headers.Companion companion = Headers.Companion;
        String header = response.request().header("referer");
        Intrinsics.checkNotNull(header);
        Headers of = companion.of(new String[]{"Referer", header});
        Document parse = Jsoup.parse(JSONUtil.INSTANCE.unescape(StringsKt.substringBefore$default(StringsKt.substringAfter$default(string, "\"html\":\"", (String) null, 2, (Object) null), "<script>", (String) null, 2, (Object) null)));
        AniWatchExtractor aniWatchExtractor = new AniWatchExtractor(getClient());
        Iterable select = parse.select("div.server-item");
        Intrinsics.checkNotNullExpressionValue(select, "serversHtml.select(\"div.server-item\")");
        return CollectionsKt.flatten(CollectionsKt.filterNotNull(parallelMap(select, new AniWatch$videoListParse$videoList$1(this, of, aniWatchExtractor, (Continuation<? super AniWatch$videoListParse$videoList$1>) null))));
    }

    /* access modifiers changed from: private */
    public final List<Video> getVideosFromServer(String str, String str2, String str3) {
        Video video;
        Iterable jsonArray;
        Boolean bool;
        String str4 = str;
        if (!StringsKt.contains$default(str4, "{\"sources\":[{\"file\":\"", false, 2, (Object) null)) {
            return null;
        }
        Json json = getJson();
        SerializersModule serializersModule = json.getSerializersModule();
        KType typeOf = Reflection.typeOf(JsonObject.class);
        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
        JsonObject jsonObject = (JsonObject) json.decodeFromString(SerializersKt.serializer(serializersModule, typeOf), str4);
        Object obj = jsonObject.get("sources");
        Intrinsics.checkNotNull(obj);
        Object obj2 = JsonElementKt.getJsonObject(JsonElementKt.getJsonArray((JsonElement) obj).get(0)).get("file");
        Intrinsics.checkNotNull(obj2);
        String content = JsonElementKt.getJsonPrimitive((JsonElement) obj2).getContent();
        List arrayList = new ArrayList();
        JsonElement jsonElement = (JsonElement) jsonObject.get("tracks");
        if (jsonElement == null || (jsonArray = JsonElementKt.getJsonArray(jsonElement)) == null) {
            CollectionsKt.emptyList();
        } else {
            Collection arrayList2 = new ArrayList();
            for (Object next : jsonArray) {
                Object obj3 = JsonElementKt.getJsonObject((JsonElement) next).get("kind");
                Intrinsics.checkNotNull(obj3);
                if (Intrinsics.areEqual(JsonElementKt.getJsonPrimitive((JsonElement) obj3).getContent(), "captions")) {
                    arrayList2.add(next);
                }
            }
            Iterable<JsonElement> iterable = (List) arrayList2;
            Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
            for (JsonElement jsonElement2 : iterable) {
                Object obj4 = JsonElementKt.getJsonObject(jsonElement2).get("file");
                Intrinsics.checkNotNull(obj4);
                String content2 = JsonElementKt.getJsonPrimitive((JsonElement) obj4).getContent();
                Object obj5 = JsonElementKt.getJsonObject(jsonElement2).get("label");
                Intrinsics.checkNotNull(obj5);
                try {
                    bool = Boolean.valueOf(arrayList.add(new Track(content2, JsonElementKt.getJsonPrimitive((JsonElement) obj5).getContent())));
                } catch (Error unused) {
                    bool = Unit.INSTANCE;
                }
                arrayList3.add(bool);
            }
            List list = (List) arrayList3;
        }
        List<Track> subLangOrder = subLangOrder(arrayList);
        Iterable<String> split$default = StringsKt.split$default(StringsKt.substringAfter$default(getClient().newCall(RequestsKt.GET$default(content, (Headers) null, (CacheControl) null, 6, (Object) null)).execute().body().string(), "#EXT-X-STREAM-INF:", (String) null, 2, (Object) null), new String[]{"#EXT-X-STREAM-INF:"}, false, 0, 6, (Object) null);
        Collection arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(split$default, 10));
        for (String str5 : split$default) {
            String str6 = str3 + " - " + StringsKt.substringBefore$default(StringsKt.substringAfter$default(StringsKt.substringAfter$default(str5, "RESOLUTION=", (String) null, 2, (Object) null), "x", (String) null, 2, (Object) null), ",", (String) null, 2, (Object) null) + "p - " + str2;
            String str7 = StringsKt.substringBeforeLast$default(content, "/", (String) null, 2, (Object) null) + '/' + StringsKt.substringBefore$default(StringsKt.substringAfter$default(str5, "\n", (String) null, 2, (Object) null), "\n", (String) null, 2, (Object) null);
            try {
                video = new Video(str7, str6, str7, (Headers) null, subLangOrder, (List) null, 40, (DefaultConstructorMarker) null);
            } catch (Error unused2) {
                video = new Video(str7, str6, str7, (Uri) null, (Headers) null, 24, (DefaultConstructorMarker) null);
            }
            arrayList4.add(video);
        }
        return (List) arrayList4;
    }

    /* access modifiers changed from: protected */
    public Void videoListSelector() {
        throw new Exception("not used");
    }

    /* access modifiers changed from: protected */
    public Void videoFromElement(Element element) {
        Intrinsics.checkNotNullParameter(element, "element");
        throw new Exception("not used");
    }

    /* access modifiers changed from: protected */
    public Void videoUrlParse(Document document) {
        Intrinsics.checkNotNullParameter(document, "document");
        throw new Exception("not used");
    }

    private final List<Video> sortIfContains(List<Video> list, String str) {
        List<Video> arrayList = new ArrayList<>();
        int i = 0;
        for (Video next : list) {
            if (StringsKt.contains$default(next.getQuality(), str, false, 2, (Object) null)) {
                arrayList.add(i, next);
                i++;
            } else {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public List<Video> sort(List<Video> list) {
        Intrinsics.checkNotNullParameter(list, "<this>");
        String string = getPreferences().getString(PREF_QUALITY_KEY, "720p");
        Intrinsics.checkNotNull(string);
        String string2 = getPreferences().getString(PREF_TYPE_KEY, "dub");
        Intrinsics.checkNotNull(string2);
        return sortIfContains(sortIfContains(list, string2), string);
    }

    private final List<Track> subLangOrder(List<Track> list) {
        String string = getPreferences().getString(PREF_SUB_KEY, (String) null);
        if (string == null) {
            return list;
        }
        List<Track> arrayList = new ArrayList<>();
        int i = 0;
        for (Track next : list) {
            if (Intrinsics.areEqual(next.getLang(), string)) {
                arrayList.add(i, next);
                i++;
            } else {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public SAnime searchAnimeFromElement(Element element) {
        Intrinsics.checkNotNullParameter(element, "element");
        return popularAnimeFromElement(element);
    }

    /* access modifiers changed from: protected */
    public String searchAnimeNextPageSelector() {
        return popularAnimeNextPageSelector();
    }

    /* access modifiers changed from: protected */
    public String searchAnimeSelector() {
        return popularAnimeSelector();
    }

    public Observable<AnimesPage> fetchSearchAnime(int i, String str, AnimeFilterList animeFilterList) {
        Intrinsics.checkNotNullParameter(str, "query");
        Intrinsics.checkNotNullParameter(animeFilterList, "filters");
        if (StringsKt.startsWith$default(str, PREFIX_SEARCH, false, 2, (Object) null)) {
            String removePrefix = StringsKt.removePrefix(str, PREFIX_SEARCH);
            OkHttpClient client2 = getClient();
            Observable<AnimesPage> map = OkHttpExtensionsKt.asObservableSuccess(client2.newCall(RequestsKt.GET$default(getBaseUrl() + '/' + removePrefix, (Headers) null, (CacheControl) null, 6, (Object) null))).map(new AniWatch$$ExternalSyntheticLambda5(new AniWatch$fetchSearchAnime$1(this, removePrefix)));
            Intrinsics.checkNotNullExpressionValue(map, "override fun fetchSearch…        }\n        }\n    }");
            return map;
        }
        Observable<AnimesPage> map2 = OkHttpExtensionsKt.asObservableSuccess(getClient().newCall(searchAnimeRequest(i, str, AniWatchFilters.INSTANCE.getSearchParameters$aniyomi_en_zoro_v13_32_release(animeFilterList)))).map(new AniWatch$$ExternalSyntheticLambda6(new AniWatch$fetchSearchAnime$2(this)));
        Intrinsics.checkNotNullExpressionValue(map2, "override fun fetchSearch…        }\n        }\n    }");
        return map2;
    }

    /* access modifiers changed from: private */
    public static final AnimesPage fetchSearchAnime$lambda$6(Function1 function1, Object obj) {
        Intrinsics.checkNotNullParameter(function1, "$tmp0");
        return (AnimesPage) function1.invoke(obj);
    }

    /* access modifiers changed from: private */
    public static final AnimesPage fetchSearchAnime$lambda$7(Function1 function1, Object obj) {
        Intrinsics.checkNotNullParameter(function1, "$tmp0");
        return (AnimesPage) function1.invoke(obj);
    }

    /* access modifiers changed from: private */
    public final AnimesPage searchAnimeBySlugParse(Response response, String str) {
        SAnime animeDetailsParse = animeDetailsParse(response);
        animeDetailsParse.setUrl("/" + str);
        return new AnimesPage(CollectionsKt.listOf(animeDetailsParse), false);
    }

    /* access modifiers changed from: protected */
    public Request searchAnimeRequest(int i, String str, AnimeFilterList animeFilterList) {
        Intrinsics.checkNotNullParameter(str, "query");
        Intrinsics.checkNotNullParameter(animeFilterList, "filters");
        throw new Exception("not used");
    }

    private final Request searchAnimeRequest(int i, String str, AniWatchFilters.FilterSearchParams filterSearchParams) {
        HttpUrl.Builder builder;
        if (str.length() == 0 ? MARK_FILLERS_DEFAULT : false) {
            HttpUrl.Companion companion = HttpUrl.Companion;
            HttpUrl parse = companion.parse(getBaseUrl() + "/filter");
            Intrinsics.checkNotNull(parse);
            builder = parse.newBuilder().addQueryParameter("page", String.valueOf(i));
        } else {
            HttpUrl.Companion companion2 = HttpUrl.Companion;
            HttpUrl parse2 = companion2.parse(getBaseUrl() + "/search");
            Intrinsics.checkNotNull(parse2);
            builder = parse2.newBuilder().addQueryParameter("page", String.valueOf(i)).addQueryParameter("keyword", str);
        }
        return RequestsKt.GET$default(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(addIfNotBlank(builder, "type", filterSearchParams.getType()), "status", filterSearchParams.getStatus()), "rated", filterSearchParams.getRated()), "score", filterSearchParams.getScore()), "season", filterSearchParams.getSeason()), "language", filterSearchParams.getLanguage()), "sort", filterSearchParams.getSort()), "sy", filterSearchParams.getStart_year()), "sm", filterSearchParams.getStart_month()), "sd", filterSearchParams.getStart_day()), "ey", filterSearchParams.getEnd_year()), "em", filterSearchParams.getEnd_month()), "ed", filterSearchParams.getEnd_day()), "genres", filterSearchParams.getGenres()).build().toString(), (Headers) null, (CacheControl) null, 6, (Object) null);
    }

    public AnimeFilterList getFilterList() {
        return AniWatchFilters.INSTANCE.getFILTER_LIST();
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0088, code lost:
        if (r14 == null) goto L_0x008a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public eu.kanade.tachiyomi.animesource.model.SAnime animeDetailsParse(org.jsoup.nodes.Document r14) {
        /*
            r13 = this;
            java.lang.String r0 = "document"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            eu.kanade.tachiyomi.animesource.model.SAnime$Companion r0 = eu.kanade.tachiyomi.animesource.model.SAnime.Companion
            eu.kanade.tachiyomi.animesource.model.SAnime r0 = r0.create()
            java.lang.String r1 = "div.anisc-info"
            org.jsoup.nodes.Element r1 = r14.selectFirst(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
            java.lang.String r2 = "div.anisc-detail"
            org.jsoup.nodes.Element r9 = r14.selectFirst(r2)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r9)
            java.lang.String r2 = "div.anisc-poster img"
            org.jsoup.nodes.Element r14 = r14.selectFirst(r2)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r14)
            java.lang.String r2 = "src"
            java.lang.String r14 = r14.attr(r2)
            r0.setThumbnail_url(r14)
            java.lang.String r14 = "h2"
            org.jsoup.nodes.Element r14 = r9.selectFirst(r14)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r14)
            java.lang.String r2 = "data-jname"
            java.lang.String r14 = r14.attr(r2)
            java.lang.String r2 = "detail.selectFirst(\"h2\")!!.attr(\"data-jname\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r2)
            r0.setTitle(r14)
            java.lang.String r4 = "Studios:"
            r5 = 0
            r6 = 0
            r7 = 6
            r8 = 0
            r2 = r13
            r3 = r1
            java.lang.String r14 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            r0.setAuthor(r14)
            java.lang.String r4 = "Status:"
            java.lang.String r14 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            int r14 = r13.parseStatus(r14)
            r0.setStatus(r14)
            java.lang.String r4 = "Genres:"
            r5 = 1
            r7 = 4
            java.lang.String r14 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            r0.setGenre(r14)
            java.lang.String r4 = "Overview:"
            r5 = 0
            r7 = 6
            java.lang.String r14 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            if (r14 == 0) goto L_0x008a
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r14)
            r14 = 10
            r2.append(r14)
            java.lang.String r14 = r2.toString()
            if (r14 != 0) goto L_0x008c
        L_0x008a:
            java.lang.String r14 = ""
        L_0x008c:
            java.lang.String r2 = "div.film-stats div.tick-dub"
            org.jsoup.select.Elements r2 = r9.select(r2)
            if (r2 == 0) goto L_0x00c0
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r14)
            java.lang.String r14 = "\nLanguage: "
            r3.append(r14)
            r4 = r2
            java.lang.Iterable r4 = (java.lang.Iterable) r4
            java.lang.String r14 = ", "
            r5 = r14
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$animeDetailsParse$1$1 r14 = p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatch$animeDetailsParse$1$1.INSTANCE
            r10 = r14
            kotlin.jvm.functions.Function1 r10 = (kotlin.jvm.functions.Function1) r10
            r11 = 30
            r12 = 0
            java.lang.String r14 = kotlin.collections.CollectionsKt.joinToString$default(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r3.append(r14)
            java.lang.String r14 = r3.toString()
        L_0x00c0:
            java.lang.String r4 = "Aired:"
            r5 = 0
            r6 = 1
            r7 = 2
            r8 = 0
            r2 = r13
            r3 = r1
            java.lang.String r2 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            if (r2 == 0) goto L_0x00dd
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r14)
            r3.append(r2)
            java.lang.String r14 = r3.toString()
        L_0x00dd:
            java.lang.String r4 = "Premiered:"
            r5 = 0
            r6 = 1
            r7 = 2
            r8 = 0
            r2 = r13
            r3 = r1
            java.lang.String r2 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            if (r2 == 0) goto L_0x00fa
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r14)
            r3.append(r2)
            java.lang.String r14 = r3.toString()
        L_0x00fa:
            java.lang.String r4 = "Synonyms:"
            r5 = 0
            r6 = 1
            r7 = 2
            r8 = 0
            r2 = r13
            r3 = r1
            java.lang.String r2 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            if (r2 == 0) goto L_0x0117
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r14)
            r3.append(r2)
            java.lang.String r14 = r3.toString()
        L_0x0117:
            java.lang.String r4 = "Japanese:"
            r5 = 0
            r6 = 1
            r7 = 2
            r8 = 0
            r2 = r13
            r3 = r1
            java.lang.String r1 = getInfo$default(r2, r3, r4, r5, r6, r7, r8)
            if (r1 == 0) goto L_0x0134
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r14)
            r2.append(r1)
            java.lang.String r14 = r2.toString()
        L_0x0134:
            r0.setDescription(r14)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatch.animeDetailsParse(org.jsoup.nodes.Document):eu.kanade.tachiyomi.animesource.model.SAnime");
    }

    /* access modifiers changed from: protected */
    public String latestUpdatesNextPageSelector() {
        return popularAnimeNextPageSelector();
    }

    /* access modifiers changed from: protected */
    public SAnime latestUpdatesFromElement(Element element) {
        Intrinsics.checkNotNullParameter(element, "element");
        return popularAnimeFromElement(element);
    }

    /* access modifiers changed from: protected */
    public Request latestUpdatesRequest(int i) {
        return RequestsKt.GET$default(getBaseUrl() + "/top-airing", (Headers) null, (CacheControl) null, 6, (Object) null);
    }

    /* access modifiers changed from: protected */
    public String latestUpdatesSelector() {
        return popularAnimeSelector();
    }

    public void setupPreferenceScreen(PreferenceScreen preferenceScreen) {
        Intrinsics.checkNotNullParameter(preferenceScreen, "screen");
        Preference listPreference = new ListPreference(preferenceScreen.getContext());
        listPreference.setKey(PREF_DOMAIN_KEY);
        listPreference.setTitle(PREF_DOMAIN_TITLE);
        listPreference.setEntries((CharSequence[]) PREF_DOMAIN_ENTRIES);
        listPreference.setEntryValues((CharSequence[]) PREF_DOMAIN_ENTRY_VALUES);
        listPreference.setDefaultValue(PREF_DOMAIN_DEFAULT);
        listPreference.setSummary("%s");
        listPreference.setOnPreferenceChangeListener(new AniWatch$$ExternalSyntheticLambda0(listPreference, this));
        Preference listPreference2 = new ListPreference(preferenceScreen.getContext());
        listPreference2.setKey(PREF_QUALITY_KEY);
        listPreference2.setTitle(PREF_QUALITY_TITLE);
        String[] strArr = PREF_QUALITY_ENTRIES;
        listPreference2.setEntries((CharSequence[]) strArr);
        listPreference2.setEntryValues((CharSequence[]) strArr);
        listPreference2.setDefaultValue("720p");
        listPreference2.setSummary("%s");
        listPreference2.setOnPreferenceChangeListener(new AniWatch$$ExternalSyntheticLambda1(listPreference2, this));
        Preference listPreference3 = new ListPreference(preferenceScreen.getContext());
        listPreference3.setKey(PREF_TYPE_KEY);
        listPreference3.setTitle(PREF_TYPE_TITLE);
        String[] strArr2 = PREF_TYPE_ENTRIES;
        listPreference3.setEntries((CharSequence[]) strArr2);
        listPreference3.setEntryValues((CharSequence[]) strArr2);
        listPreference3.setDefaultValue("dub");
        listPreference3.setSummary("%s");
        listPreference3.setOnPreferenceChangeListener(new AniWatch$$ExternalSyntheticLambda2(listPreference3, this));
        Preference listPreference4 = new ListPreference(preferenceScreen.getContext());
        listPreference4.setKey(PREF_SUB_KEY);
        listPreference4.setTitle(PREF_SUB_TITLE);
        String[] strArr3 = PREF_SUB_ENTRIES;
        listPreference4.setEntries((CharSequence[]) strArr3);
        listPreference4.setEntryValues((CharSequence[]) strArr3);
        listPreference4.setDefaultValue("English");
        listPreference4.setSummary("%s");
        listPreference4.setOnPreferenceChangeListener(new AniWatch$$ExternalSyntheticLambda3(listPreference4, this));
        Preference switchPreferenceCompat = new SwitchPreferenceCompat(preferenceScreen.getContext());
        switchPreferenceCompat.setKey(MARK_FILLERS_KEY);
        switchPreferenceCompat.setTitle(MARK_FILLERS_TITLE);
        switchPreferenceCompat.setDefaultValue(Boolean.valueOf(MARK_FILLERS_DEFAULT));
        switchPreferenceCompat.setOnPreferenceChangeListener(new AniWatch$$ExternalSyntheticLambda4(this, switchPreferenceCompat));
        preferenceScreen.addPreference(listPreference);
        preferenceScreen.addPreference(listPreference2);
        preferenceScreen.addPreference(listPreference3);
        preferenceScreen.addPreference(listPreference4);
        preferenceScreen.addPreference(switchPreferenceCompat);
    }

    /* access modifiers changed from: private */
    public static final boolean setupPreferenceScreen$lambda$15$lambda$14(ListPreference listPreference, AniWatch aniWatch, Preference preference, Object obj) {
        Intrinsics.checkNotNullParameter(listPreference, "$this_apply");
        Intrinsics.checkNotNullParameter(aniWatch, "this$0");
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.String");
        CharSequence charSequence = listPreference.getEntryValues()[listPreference.findIndexOfValue((String) obj)];
        Intrinsics.checkNotNull(charSequence, "null cannot be cast to non-null type kotlin.String");
        return aniWatch.getPreferences().edit().putString(listPreference.getKey(), (String) charSequence).commit();
    }

    /* access modifiers changed from: private */
    public static final boolean setupPreferenceScreen$lambda$17$lambda$16(ListPreference listPreference, AniWatch aniWatch, Preference preference, Object obj) {
        Intrinsics.checkNotNullParameter(listPreference, "$this_apply");
        Intrinsics.checkNotNullParameter(aniWatch, "this$0");
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.String");
        CharSequence charSequence = listPreference.getEntryValues()[listPreference.findIndexOfValue((String) obj)];
        Intrinsics.checkNotNull(charSequence, "null cannot be cast to non-null type kotlin.String");
        return aniWatch.getPreferences().edit().putString(listPreference.getKey(), (String) charSequence).commit();
    }

    /* access modifiers changed from: private */
    public static final boolean setupPreferenceScreen$lambda$19$lambda$18(ListPreference listPreference, AniWatch aniWatch, Preference preference, Object obj) {
        Intrinsics.checkNotNullParameter(listPreference, "$this_apply");
        Intrinsics.checkNotNullParameter(aniWatch, "this$0");
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.String");
        CharSequence charSequence = listPreference.getEntryValues()[listPreference.findIndexOfValue((String) obj)];
        Intrinsics.checkNotNull(charSequence, "null cannot be cast to non-null type kotlin.String");
        return aniWatch.getPreferences().edit().putString(listPreference.getKey(), (String) charSequence).commit();
    }

    /* access modifiers changed from: private */
    public static final boolean setupPreferenceScreen$lambda$21$lambda$20(ListPreference listPreference, AniWatch aniWatch, Preference preference, Object obj) {
        Intrinsics.checkNotNullParameter(listPreference, "$this_apply");
        Intrinsics.checkNotNullParameter(aniWatch, "this$0");
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.String");
        CharSequence charSequence = listPreference.getEntryValues()[listPreference.findIndexOfValue((String) obj)];
        Intrinsics.checkNotNull(charSequence, "null cannot be cast to non-null type kotlin.String");
        return aniWatch.getPreferences().edit().putString(listPreference.getKey(), (String) charSequence).commit();
    }

    /* access modifiers changed from: private */
    public static final boolean setupPreferenceScreen$lambda$23$lambda$22(AniWatch aniWatch, SwitchPreferenceCompat switchPreferenceCompat, Preference preference, Object obj) {
        Intrinsics.checkNotNullParameter(aniWatch, "this$0");
        Intrinsics.checkNotNullParameter(switchPreferenceCompat, "$this_apply");
        SharedPreferences.Editor edit = aniWatch.getPreferences().edit();
        String key = switchPreferenceCompat.getKey();
        Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.Boolean");
        return edit.putBoolean(key, ((Boolean) obj).booleanValue()).commit();
    }

    private final int parseStatus(String str) {
        if (Intrinsics.areEqual(str, "Currently Airing")) {
            return 1;
        }
        return Intrinsics.areEqual(str, "Finished Airing") ? 2 : 0;
    }

    static /* synthetic */ String getInfo$default(AniWatch aniWatch, Element element, String str, boolean z, boolean z2, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        if ((i & 4) != 0) {
            z2 = false;
        }
        return aniWatch.getInfo(element, str, z, z2);
    }

    private final String getInfo(Element element, String str, boolean z, boolean z2) {
        if (z) {
            Iterable select = element.select("div.item-list:contains(" + str + ") > a");
            Intrinsics.checkNotNullExpressionValue(select, "elements");
            return CollectionsKt.joinToString$default(select, ", ", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, AniWatch$getInfo$1.INSTANCE, 30, (Object) null);
        }
        Element selectFirst = element.selectFirst("div.item-title:contains(" + str + ')');
        if (selectFirst == null) {
            return null;
        }
        Element selectFirst2 = selectFirst.selectFirst("*.name, *.text");
        Intrinsics.checkNotNull(selectFirst2);
        String text = selectFirst2.text();
        if (!z2) {
            return text;
        }
        return "\n" + str + ' ' + text;
    }

    private final HttpUrl.Builder addIfNotBlank(HttpUrl.Builder builder, String str, String str2) {
        if (StringsKt.isBlank(str2) ^ MARK_FILLERS_DEFAULT) {
            builder.addQueryParameter(str, str2);
        }
        return builder;
    }

    private final <A, B> List<B> parallelMap(Iterable<? extends A> iterable, Function2<? super A, ? super Continuation<? super B>, ? extends Object> function2) {
        return (List) BuildersKt.runBlocking$default((CoroutineContext) null, new AniWatch$parallelMap$1(iterable, function2, (Continuation<? super AniWatch$parallelMap$1>) null), 1, (Object) null);
    }

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u000e\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\u000bX\u0004¢\u0006\u0004\n\u0002\u0010\fR\u0016\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00060\u000bX\u0004¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u000e\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u000bX\u0004¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u0011\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u0016\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00060\u000bX\u0004¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u0014\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u0016\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00060\u000bX\u0004¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u0017\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0006XT¢\u0006\u0002\n\u0000¨\u0006\u0019"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatch$Companion;", "", "()V", "MARK_FILLERS_DEFAULT", "", "MARK_FILLERS_KEY", "", "MARK_FILLERS_TITLE", "PREFIX_SEARCH", "PREF_DOMAIN_DEFAULT", "PREF_DOMAIN_ENTRIES", "", "[Ljava/lang/String;", "PREF_DOMAIN_ENTRY_VALUES", "PREF_DOMAIN_KEY", "PREF_DOMAIN_TITLE", "PREF_QUALITY_ENTRIES", "PREF_QUALITY_KEY", "PREF_QUALITY_TITLE", "PREF_SUB_ENTRIES", "PREF_SUB_KEY", "PREF_SUB_TITLE", "PREF_TYPE_ENTRIES", "PREF_TYPE_KEY", "PREF_TYPE_TITLE", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$Companion */
    /* compiled from: AniWatch.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import kotlin.jvm.functions.Function1;
import rx.functions.Func1;

/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$$ExternalSyntheticLambda6 */
/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AniWatch$$ExternalSyntheticLambda6 implements Func1 {
    public final /* synthetic */ Function1 f$0;

    public /* synthetic */ AniWatch$$ExternalSyntheticLambda6(Function1 function1) {
        this.f$0 = function1;
    }

    public final Object call(Object obj) {
        return AniWatch.fetchSearchAnime$lambda$7(this.f$0, obj);
    }
}

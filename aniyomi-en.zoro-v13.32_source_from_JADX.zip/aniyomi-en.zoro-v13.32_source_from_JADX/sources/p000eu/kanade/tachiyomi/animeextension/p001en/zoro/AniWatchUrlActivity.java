package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import android.app.Activity;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0014R\u000e\u0010\u0003\u001a\u00020\u0004XD¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/AniWatchUrlActivity;", "Landroid/app/Activity;", "()V", "tag", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatchUrlActivity */
/* compiled from: AniWatchUrlActivity.kt */
public final class AniWatchUrlActivity extends Activity {
    private final String tag = "AniWatchUrlActivity";

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0009, code lost:
        r5 = r5.getData();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onCreate(android.os.Bundle r5) {
        /*
            r4 = this;
            super.onCreate(r5)
            android.content.Intent r5 = r4.getIntent()
            if (r5 == 0) goto L_0x0014
            android.net.Uri r5 = r5.getData()
            if (r5 == 0) goto L_0x0014
            java.util.List r5 = r5.getPathSegments()
            goto L_0x0015
        L_0x0014:
            r5 = 0
        L_0x0015:
            r0 = 0
            if (r5 == 0) goto L_0x0059
            int r1 = r5.size()
            if (r1 <= 0) goto L_0x0059
            java.lang.Object r5 = r5.get(r0)
            java.lang.String r5 = (java.lang.String) r5
            android.content.Intent r1 = new android.content.Intent
            r1.<init>()
            java.lang.String r2 = "eu.kanade.tachiyomi.ANIMESEARCH"
            r1.setAction(r2)
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "slug:"
            r2.<init>(r3)
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            java.lang.String r2 = "query"
            r1.putExtra(r2, r5)
            java.lang.String r5 = "filter"
            java.lang.String r2 = r4.getPackageName()
            r1.putExtra(r5, r2)
            r4.startActivity(r1)     // Catch:{ ActivityNotFoundException -> 0x004e }
            goto L_0x0070
        L_0x004e:
            r5 = move-exception
            java.lang.String r1 = r4.tag
            java.lang.String r5 = r5.toString()
            android.util.Log.e(r1, r5)
            goto L_0x0070
        L_0x0059:
            java.lang.String r5 = r4.tag
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "could not parse uri from intent "
            r1.<init>(r2)
            android.content.Intent r2 = r4.getIntent()
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r5, r1)
        L_0x0070:
            r4.finish()
            java.lang.System.exit(r0)
            java.lang.RuntimeException r5 = new java.lang.RuntimeException
            java.lang.String r0 = "System.exit returned normally, while it was supposed to halt JVM."
            r5.<init>(r0)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatchUrlActivity.onCreate(android.os.Bundle):void");
    }
}

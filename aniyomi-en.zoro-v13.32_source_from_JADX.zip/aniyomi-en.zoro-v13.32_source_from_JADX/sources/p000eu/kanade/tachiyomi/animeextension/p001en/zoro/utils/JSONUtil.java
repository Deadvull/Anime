package p000eu.kanade.tachiyomi.animeextension.p001en.zoro.utils;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.CharsKt;

@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004J\u000e\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004¨\u0006\u0007"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/utils/JSONUtil;", "", "()V", "escape", "", "input", "unescape", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.utils.JSONUtil */
/* compiled from: JSONUtil.kt */
public final class JSONUtil {
    public static final JSONUtil INSTANCE = new JSONUtil();

    private JSONUtil() {
    }

    public final String escape(String str) {
        Object obj;
        Intrinsics.checkNotNullParameter(str, "input");
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (charAt == 8) {
                obj = "\\b";
            } else if (charAt == 12) {
                obj = "\\f";
            } else if (charAt == 10) {
                obj = "\\n";
            } else if (charAt == 13) {
                obj = "\\r";
            } else if (charAt == 9) {
                obj = "\\t";
            } else if (charAt == '\\') {
                obj = "\\\\";
            } else if (charAt == '\"') {
                obj = "\\\"";
            } else if (charAt > 127) {
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                obj = String.format("\\u%04x", Arrays.copyOf(new Object[]{Integer.valueOf(charAt)}, 1));
                Intrinsics.checkNotNullExpressionValue(obj, "format(format, *args)");
            } else {
                obj = Character.valueOf(charAt);
            }
            sb.append(obj);
        }
        String sb2 = sb.toString();
        Intrinsics.checkNotNullExpressionValue(sb2, "output.toString()");
        return sb2;
    }

    public final String unescape(String str) {
        Intrinsics.checkNotNullParameter(str, "input");
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < str.length()) {
            char charAt = str.charAt(i);
            i++;
            if (charAt != '\\' || i >= str.length()) {
                sb.append(charAt);
            } else {
                char charAt2 = str.charAt(i);
                i++;
                boolean z = true;
                if (!(((charAt2 == '\\' || charAt2 == '/') || charAt2 == '\"') || charAt2 == '\'')) {
                    if (charAt2 == 'b') {
                        charAt2 = 8;
                    } else if (charAt2 == 'f') {
                        charAt2 = 12;
                    } else if (charAt2 == 'n') {
                        charAt2 = 10;
                    } else if (charAt2 == 'r') {
                        charAt2 = 13;
                    } else if (charAt2 == 't') {
                        charAt2 = 9;
                    } else if (charAt2 == 'u') {
                        int i2 = i + 4;
                        if (i2 <= str.length()) {
                            String substring = str.substring(i, i2);
                            Intrinsics.checkNotNullExpressionValue(substring, "this as java.lang.String…ing(startIndex, endIndex)");
                            CharSequence charSequence = substring;
                            int i3 = 0;
                            while (true) {
                                if (i3 >= charSequence.length()) {
                                    z = false;
                                    break;
                                } else if (!Character.isLetterOrDigit(charSequence.charAt(i3))) {
                                    break;
                                } else {
                                    i3++;
                                }
                            }
                            if (!z) {
                                charAt2 = (char) Integer.parseInt(substring, CharsKt.checkRadix(16));
                            } else {
                                throw new RuntimeException("Bad character in unicode escape.");
                            }
                        } else {
                            throw new RuntimeException("Not enough unicode digits!");
                        }
                    } else {
                        throw new RuntimeException("Illegal escape sequence: \\" + charAt2);
                    }
                }
                sb.append(charAt2);
            }
        }
        String sb2 = sb.toString();
        Intrinsics.checkNotNullExpressionValue(sb2, "builder.toString()");
        return sb2;
    }
}

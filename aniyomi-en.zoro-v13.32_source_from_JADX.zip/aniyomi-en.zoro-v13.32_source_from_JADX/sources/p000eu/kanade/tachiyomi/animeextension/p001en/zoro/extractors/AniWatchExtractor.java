package p000eu.kanade.tachiyomi.animeextension.p001en.zoro.extractors;

import eu.kanade.tachiyomi.network.RequestsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import p000eu.kanade.tachiyomi.animeextension.p001en.zoro.utils.Decryptor;

@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 \u000b2\u00020\u0001:\u0001\u000bB\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\n\u001a\u00020\tR\u000e\u0010\u0005\u001a\u00020\u0006X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/extractors/AniWatchExtractor;", "", "client", "Lokhttp3/OkHttpClient;", "(Lokhttp3/OkHttpClient;)V", "cacheControl", "Lokhttp3/CacheControl;", "newClient", "getSourcesJson", "", "url", "Companion", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.extractors.AniWatchExtractor */
/* compiled from: AniWatchExtractor.kt */
public final class AniWatchExtractor {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    private static final String[] SERVER_URL = {"https://megacloud.tv", "https://rapid-cloud.co"};
    private static final String[] SOURCES_KEY = {"6", "0"};
    private static final String[] SOURCES_SPLITTER = {"/e-1/", "/embed-6/"};
    private static final String[] SOURCES_URL = {"/embed-2/ajax/e-1/getSources?id=", "/ajax/embed-6/getSources?id="};
    private final CacheControl cacheControl = new CacheControl.Builder().noStore().build();
    private final OkHttpClient client;
    private final OkHttpClient newClient;

    public AniWatchExtractor(OkHttpClient okHttpClient) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        this.client = okHttpClient;
        this.newClient = okHttpClient.newBuilder().cache((Cache) null).build();
    }

    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0004¢\u0006\u0004\n\u0002\u0010\u0006R\u0016\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0004¢\u0006\u0004\n\u0002\u0010\u0006R\u0016\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0004¢\u0006\u0004\n\u0002\u0010\u0006R\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0004¢\u0006\u0004\n\u0002\u0010\u0006¨\u0006\n"}, d2 = {"Leu/kanade/tachiyomi/animeextension/en/zoro/extractors/AniWatchExtractor$Companion;", "", "()V", "SERVER_URL", "", "", "[Ljava/lang/String;", "SOURCES_KEY", "SOURCES_SPLITTER", "SOURCES_URL", "aniyomi-en.zoro-v13.32_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.extractors.AniWatchExtractor$Companion */
    /* compiled from: AniWatchExtractor.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public final String getSourcesJson(String str) {
        String substringBefore$default;
        String decrypt;
        Intrinsics.checkNotNullParameter(str, "url");
        boolean z = true;
        char c = !StringsKt.startsWith$default(str, "https://megacloud.tv", false, 2, (Object) null);
        String str2 = SOURCES_KEY[c];
        CharSequence substringBefore = StringsKt.substringBefore(StringsKt.substringAfter(str, SOURCES_SPLITTER[c], ""), "?", "");
        if (substringBefore.length() != 0) {
            z = false;
        }
        if (z) {
            return null;
        }
        String string = this.newClient.newCall(RequestsKt.GET$default(SERVER_URL[c] + SOURCES_URL[c] + ((String) substringBefore), (Headers) null, this.cacheControl, 2, (Object) null)).execute().body().string();
        String string2 = this.newClient.newCall(RequestsKt.GET$default("https://raw.githubusercontent.com/enimax-anime/key/e" + str2 + "/key.txt", (Headers) null, (CacheControl) null, 6, (Object) null)).execute().body().string();
        CharSequence charSequence = string;
        if (StringsKt.contains$default(charSequence, "\"encrypted\":false", false, 2, (Object) null)) {
            return string;
        }
        if (!StringsKt.contains$default(charSequence, "{\"sources\":", false, 2, (Object) null) || (decrypt = Decryptor.INSTANCE.decrypt((substringBefore$default = StringsKt.substringBefore$default(StringsKt.substringAfter$default(string, "sources\":\"", (String) null, 2, (Object) null), "\"", (String) null, 2, (Object) null)), string2)) == null) {
            return null;
        }
        return StringsKt.replace$default(string, "\"" + substringBefore$default + '\"', decrypt, false, 4, (Object) null);
    }
}

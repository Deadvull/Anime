package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.AwaitKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Dispatchers;

@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0003\"\u0004\b\u0001\u0010\u0002*\u00020\u0004H@"}, d2 = {"<anonymous>", "", "B", "A", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$parallelMap$1", f = "AniWatch.kt", i = {}, l = {453}, m = "invokeSuspend", n = {}, s = {})
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$parallelMap$1 */
/* compiled from: AniWatch.kt */
final class AniWatch$parallelMap$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super List<? extends B>>, Object> {

    /* renamed from: $f */
    final /* synthetic */ Function2<A, Continuation<? super B>, Object> f1$f;
    final /* synthetic */ Iterable<A> $this_parallelMap;
    private /* synthetic */ Object L$0;
    int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AniWatch$parallelMap$1(Iterable<? extends A> iterable, Function2<? super A, ? super Continuation<? super B>, ? extends Object> function2, Continuation<? super AniWatch$parallelMap$1> continuation) {
        super(2, continuation);
        this.$this_parallelMap = iterable;
        this.f1$f = function2;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        Continuation<Unit> aniWatch$parallelMap$1 = new AniWatch$parallelMap$1(this.$this_parallelMap, this.f1$f, continuation);
        aniWatch$parallelMap$1.L$0 = obj;
        return (Continuation) aniWatch$parallelMap$1;
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super List<? extends B>> continuation) {
        return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            CoroutineScope coroutineScope = (CoroutineScope) this.L$0;
            Iterable<A> iterable = this.$this_parallelMap;
            Function2<A, Continuation<? super B>, Object> function2 = this.f1$f;
            Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
            for (A aniWatch$parallelMap$1$1$1 : iterable) {
                CoroutineScope coroutineScope2 = coroutineScope;
                arrayList.add(BuildersKt.async$default(coroutineScope2, Dispatchers.getDefault(), (CoroutineStart) null, new AniWatch$parallelMap$1$1$1(function2, aniWatch$parallelMap$1$1$1, (Continuation<? super AniWatch$parallelMap$1$1$1>) null), 2, (Object) null));
            }
            this.label = 1;
            obj = AwaitKt.awaitAll((List) arrayList, (Continuation) this);
            if (obj == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}

package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

@Metadata(d1 = {"\u0000\b\n\u0002\b\u0003\n\u0002\u0018\u0002\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0001*\u00020\u0003H@"}, d2 = {"<anonymous>", "B", "A", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$parallelMap$1$1$1", f = "AniWatch.kt", i = {}, l = {453}, m = "invokeSuspend", n = {}, s = {})
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$parallelMap$1$1$1 */
/* compiled from: AniWatch.kt */
final class AniWatch$parallelMap$1$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super B>, Object> {

    /* renamed from: $f */
    final /* synthetic */ Function2<A, Continuation<? super B>, Object> f2$f;
    final /* synthetic */ A $it;
    int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AniWatch$parallelMap$1$1$1(Function2<? super A, ? super Continuation<? super B>, ? extends Object> function2, A a, Continuation<? super AniWatch$parallelMap$1$1$1> continuation) {
        super(2, continuation);
        this.f2$f = function2;
        this.$it = a;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return (Continuation) new AniWatch$parallelMap$1$1$1(this.f2$f, this.$it, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super B> continuation) {
        return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            Function2<A, Continuation<? super B>, Object> function2 = this.f2$f;
            A a = this.$it;
            this.label = 1;
            obj = function2.invoke(a, this);
            if (obj == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}

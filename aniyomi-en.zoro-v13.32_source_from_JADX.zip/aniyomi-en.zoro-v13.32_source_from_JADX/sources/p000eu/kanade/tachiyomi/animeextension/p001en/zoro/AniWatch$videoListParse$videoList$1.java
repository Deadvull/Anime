package p000eu.kanade.tachiyomi.animeextension.p001en.zoro;

import eu.kanade.tachiyomi.animesource.model.Video;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import okhttp3.Headers;
import org.jsoup.nodes.Element;
import p000eu.kanade.tachiyomi.animeextension.p001en.zoro.extractors.AniWatchExtractor;

@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u00012\u000e\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004H@"}, d2 = {"<anonymous>", "", "Leu/kanade/tachiyomi/animesource/model/Video;", "server", "Lorg/jsoup/nodes/Element;", "kotlin.jvm.PlatformType"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$videoListParse$videoList$1", f = "AniWatch.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* renamed from: eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch$videoListParse$videoList$1 */
/* compiled from: AniWatch.kt */
final class AniWatch$videoListParse$videoList$1 extends SuspendLambda implements Function2<Element, Continuation<? super List<? extends Video>>, Object> {
    final /* synthetic */ Headers $episodeReferer;
    final /* synthetic */ AniWatchExtractor $extractor;
    /* synthetic */ Object L$0;
    int label;
    final /* synthetic */ AniWatch this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AniWatch$videoListParse$videoList$1(AniWatch aniWatch, Headers headers, AniWatchExtractor aniWatchExtractor, Continuation<? super AniWatch$videoListParse$videoList$1> continuation) {
        super(2, continuation);
        this.this$0 = aniWatch;
        this.$episodeReferer = headers;
        this.$extractor = aniWatchExtractor;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        Continuation<Unit> aniWatch$videoListParse$videoList$1 = new AniWatch$videoListParse$videoList$1(this.this$0, this.$episodeReferer, this.$extractor, continuation);
        aniWatch$videoListParse$videoList$1.L$0 = obj;
        return (Continuation) aniWatch$videoListParse$videoList$1;
    }

    public final Object invoke(Element element, Continuation<? super List<Video>> continuation) {
        return create(element, continuation).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0132  */
    /* JADX WARNING: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r20) {
        /*
            r19 = this;
            r1 = r19
            java.lang.String r0 = "StreamTape - "
            java.lang.String r2 = "- "
            kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r3 = r1.label
            if (r3 != 0) goto L_0x0134
            kotlin.ResultKt.throwOnFailure(r20)
            java.lang.Object r3 = r1.L$0
            org.jsoup.nodes.Element r3 = (org.jsoup.nodes.Element) r3
            java.lang.String r4 = r3.text()
            java.lang.String r5 = "data-id"
            java.lang.String r5 = r3.attr(r5)
            java.lang.String r6 = "data-type"
            java.lang.String r3 = r3.attr(r6)
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch r6 = r1.this$0
            java.lang.String r6 = r6.getBaseUrl()
            java.lang.String r7 = "https://kaido.to"
            boolean r6 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r7)
            if (r6 == 0) goto L_0x0035
            java.lang.String r6 = ""
            goto L_0x0037
        L_0x0035:
            java.lang.String r6 = "/v2"
        L_0x0037:
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch r8 = r1.this$0
            java.lang.String r8 = r8.getBaseUrl()
            r7.append(r8)
            java.lang.String r8 = "/ajax"
            r7.append(r8)
            r7.append(r6)
            java.lang.String r6 = "/episode/sources?id="
            r7.append(r6)
            r7.append(r5)
            java.lang.String r5 = r7.toString()
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch r6 = r1.this$0
            okhttp3.OkHttpClient r6 = r6.getClient()
            okhttp3.Headers r7 = r1.$episodeReferer
            r8 = 4
            r9 = 0
            okhttp3.Request r5 = eu.kanade.tachiyomi.network.RequestsKt.GET$default(r5, r7, r9, r8, r9)
            okhttp3.Call r5 = r6.newCall(r5)
            okhttp3.Response r5 = r5.execute()
            okhttp3.ResponseBody r5 = r5.body()
            java.lang.String r5 = r5.string()
            java.lang.String r6 = "\"link\":\""
            r7 = 2
            java.lang.String r5 = kotlin.text.StringsKt.substringAfter$default(r5, r6, r9, r7, r9)
            java.lang.String r6 = "\""
            java.lang.String r11 = kotlin.text.StringsKt.substringBefore$default(r5, r6, r9, r7, r9)
            eu.kanade.tachiyomi.animeextension.en.zoro.AniWatch r5 = r1.this$0
            eu.kanade.tachiyomi.animeextension.en.zoro.extractors.AniWatchExtractor r6 = r1.$extractor
            kotlin.Result$Companion r8 = kotlin.Result.Companion     // Catch:{ all -> 0x0120 }
            java.lang.String r8 = "name"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r8)     // Catch:{ all -> 0x0120 }
            r8 = r4
            java.lang.CharSequence r8 = (java.lang.CharSequence) r8     // Catch:{ all -> 0x0120 }
            java.lang.String r10 = "Vidstreaming"
            java.lang.CharSequence r10 = (java.lang.CharSequence) r10     // Catch:{ all -> 0x0120 }
            r12 = 0
            boolean r8 = kotlin.text.StringsKt.contains$default(r8, r10, r12, r7, r9)     // Catch:{ all -> 0x0120 }
            if (r8 != 0) goto L_0x010a
            r8 = r4
            java.lang.CharSequence r8 = (java.lang.CharSequence) r8     // Catch:{ all -> 0x0120 }
            java.lang.String r10 = "Vidcloud"
            java.lang.CharSequence r10 = (java.lang.CharSequence) r10     // Catch:{ all -> 0x0120 }
            boolean r8 = kotlin.text.StringsKt.contains$default(r8, r10, r12, r7, r9)     // Catch:{ all -> 0x0120 }
            if (r8 == 0) goto L_0x00ab
            goto L_0x010a
        L_0x00ab:
            r6 = r4
            java.lang.CharSequence r6 = (java.lang.CharSequence) r6     // Catch:{ all -> 0x0120 }
            java.lang.String r8 = "StreamSB"
            java.lang.CharSequence r8 = (java.lang.CharSequence) r8     // Catch:{ all -> 0x0120 }
            boolean r6 = kotlin.text.StringsKt.contains$default(r6, r8, r12, r7, r9)     // Catch:{ all -> 0x0120 }
            if (r6 == 0) goto L_0x00de
            eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor r10 = new eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor     // Catch:{ all -> 0x0120 }
            okhttp3.OkHttpClient r0 = r5.getClient()     // Catch:{ all -> 0x0120 }
            r10.<init>(r0)     // Catch:{ all -> 0x0120 }
            okhttp3.Headers r12 = r5.getHeaders()     // Catch:{ all -> 0x0120 }
            r13 = 0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x0120 }
            r0.<init>(r2)     // Catch:{ all -> 0x0120 }
            r0.append(r3)     // Catch:{ all -> 0x0120 }
            java.lang.String r14 = r0.toString()     // Catch:{ all -> 0x0120 }
            r15 = 0
            r16 = 0
            r17 = 52
            r18 = 0
            java.util.List r0 = p000eu.kanade.tachiyomi.lib.streamsbextractor.StreamSBExtractor.videosFromUrl$default(r10, r11, r12, r13, r14, r15, r16, r17, r18)     // Catch:{ all -> 0x0120 }
            goto L_0x011b
        L_0x00de:
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4     // Catch:{ all -> 0x0120 }
            java.lang.String r2 = "Streamtape"
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2     // Catch:{ all -> 0x0120 }
            boolean r2 = kotlin.text.StringsKt.contains$default(r4, r2, r12, r7, r9)     // Catch:{ all -> 0x0120 }
            if (r2 == 0) goto L_0x011a
            eu.kanade.tachiyomi.lib.streamtapeextractor.StreamTapeExtractor r2 = new eu.kanade.tachiyomi.lib.streamtapeextractor.StreamTapeExtractor     // Catch:{ all -> 0x0120 }
            okhttp3.OkHttpClient r4 = r5.getClient()     // Catch:{ all -> 0x0120 }
            r2.<init>(r4)     // Catch:{ all -> 0x0120 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0120 }
            r4.<init>(r0)     // Catch:{ all -> 0x0120 }
            r4.append(r3)     // Catch:{ all -> 0x0120 }
            java.lang.String r0 = r4.toString()     // Catch:{ all -> 0x0120 }
            eu.kanade.tachiyomi.animesource.model.Video r0 = r2.videoFromUrl(r11, r0)     // Catch:{ all -> 0x0120 }
            if (r0 == 0) goto L_0x011a
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)     // Catch:{ all -> 0x0120 }
            goto L_0x011b
        L_0x010a:
            java.lang.String r0 = r6.getSourcesJson(r11)     // Catch:{ all -> 0x0120 }
            if (r0 == 0) goto L_0x011a
            java.lang.String r2 = "subDub"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r2)     // Catch:{ all -> 0x0120 }
            java.util.List r0 = r5.getVideosFromServer(r0, r3, r4)     // Catch:{ all -> 0x0120 }
            goto L_0x011b
        L_0x011a:
            r0 = r9
        L_0x011b:
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)     // Catch:{ all -> 0x0120 }
            goto L_0x012b
        L_0x0120:
            r0 = move-exception
            kotlin.Result$Companion r2 = kotlin.Result.Companion
            java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)
        L_0x012b:
            boolean r2 = kotlin.Result.isFailure-impl(r0)
            if (r2 == 0) goto L_0x0132
            goto L_0x0133
        L_0x0132:
            r9 = r0
        L_0x0133:
            return r9
        L_0x0134:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000eu.kanade.tachiyomi.animeextension.p001en.zoro.AniWatch$videoListParse$videoList$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
